/* XPM */
static char *minbutup[] =
{
  "14 7 3 1",
  ". c none",
  "X c #ffffff",
  "o c #303030",
  "......oX......",
  ".....ooXX.....",
  "....oo..XX....",
  "...oo....XX...",
  "..oo......XX..",
  ".oo........XX.",
  "oXXXXXXXXXXXXX"};
