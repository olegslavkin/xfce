GtkWidget *create_xfumed_window (XFMENU * xfmenu);
GtkWidget *create_edit_dialog (XFMENU * xfmenu);

#define TARGET_NAME	"list_item"
#define TARGET_ID	12345
