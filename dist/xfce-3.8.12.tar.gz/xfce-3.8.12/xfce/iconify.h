/* XPM */
static char *iconify[] = {
  "3 3 3 1",
  ". c none",
  "X c #303030",
  "o c #f0f0f0",
  "XXo",
  "X.o",
  "Xoo"
};
