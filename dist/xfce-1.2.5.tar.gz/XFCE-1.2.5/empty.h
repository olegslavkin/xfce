/*
   XPM 
 */
static char *empty[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "     2     2        1            1",
/*
   colors 
 */
  ". c none",
/*
   pixels 
 */
  "..",
  ".."
};
