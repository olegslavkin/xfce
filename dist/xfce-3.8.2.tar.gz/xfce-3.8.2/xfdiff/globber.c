
/* globber.c */
/* 
   Copyright 2000 Edscott Wilson Garcia

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA.  */

/*****************************************************************/
 

#define GLOBBER_C
#include "globber.h"

static int display(char *input){
	printf("%s\n",input); /*fflush(NULL);*/
	return 0;
}

/* if the user defined "operate" function returns TRUE, Globber will exit 
 * and return to calling module with the same return value  */
int globber(char *path,int (*operate)(char *),char *filter) {
	glob_t  dirlist;
	int i,pass=0;
	struct stat st,*stinit=NULL;
	char *globstring;
	if (!type) type=S_IFREG;
	if (options&VERBOSE) fprintf(stderr,"path= %s\n",path);
	
	dirlist.gl_offs=2;
	if (!operate) operate=display;
	
	if (filter){
		globstring = (char *)malloc(strlen(path)+strlen(filter)+2);
		strcpy(globstring,path);
		if (path[strlen(path)-1]!='/') strcat(globstring,"/");
		strcat(globstring,filter);
		if (glob(globstring,GLOB_ERR|GLOB_TILDE,NULL,&dirlist) != 0) {
			if (options&VERBOSE) fprintf(stderr,"%s: no match\n",globstring);
		}
		else for (i=0;i<dirlist.gl_pathc;i++) {
			lstat(dirlist.gl_pathv[i],&st);

			if (options&XDEV){
			       if (stinit==NULL) {
			       		stinit=(struct stat *) malloc(sizeof (struct stat));
					lstat(dirlist.gl_pathv[i],stinit);
			       }
				else {
					if (st.st_dev != stinit->st_dev) continue; /* dont leave filesystem */
				}
			}
			if ((GLOBBER_user) && (GLOBBER_user-1 != st.st_uid)) continue;	
			if ((GLOBBER_group) && (GLOBBER_group-1 != st.st_gid)) continue;	

			if ((hour_t > 0) && ((time(NULL)-st.st_mtime)/HOUR_T > hour_t)) continue;
			if ((day_t > 0) && ((time(NULL)-st.st_mtime)/DAY_T > day_t)) continue;
			if ((month_t > 0) && ((time(NULL)-st.st_mtime)/MONTH_T > month_t)) continue;
			if ((size < 0)&&(st.st_size > -size)) continue;
			if ((size > 0)&&(st.st_size < size)) continue;
			if (type & 07777){ /* suid or exe files are selected */
				if ( (st.st_mode & 07777) & (type & 07777) ) ; /* file matches type */
				else continue;
			}
			if ((st.st_mode & S_IFMT)==(type & S_IFMT)) {
				if ((pass=(*(operate))(dirlist.gl_pathv[i]))!=0) break;
			}
		} 
		free(globstring);
		globfree(&dirlist);
		if (pass) return (pass); /* error returned from function */
	}
	
	else {
		globstring = path;
		if (glob(globstring,GLOB_ERR|GLOB_TILDE,NULL,&dirlist) != 0) {
			if (options&VERBOSE) fprintf(stderr,"%s: no match\n",globstring);
		}
		else for (i=0;i<dirlist.gl_pathc;i++) {
			lstat(dirlist.gl_pathv[i],&st);

			if (options&XDEV){
			       if (stinit==NULL) {
			       		stinit=(struct stat *) malloc(sizeof (struct stat));
					lstat(dirlist.gl_pathv[i],stinit);
			       }
				else {
					if (st.st_dev != stinit->st_dev) continue; /* dont leave filesystem */
				}
			}	
			if ((GLOBBER_user) && (GLOBBER_user-1 != st.st_uid)) continue;	
			if ((GLOBBER_group) && (GLOBBER_group-1 != st.st_gid)) continue;	

			if ((hour_t > 0) && ((time(NULL)-st.st_mtime)/HOUR_T > hour_t)) continue;
			if ((day_t > 0) && ((time(NULL)-st.st_mtime)/DAY_T > day_t)) continue;
			if ((month_t > 0) && ((time(NULL)-st.st_mtime)/MONTH_T > month_t)) continue;
			if ((size < 0)&&(st.st_size > -size)) continue;
			if ((size > 0)&&(st.st_size < size)) continue;
			
			if (type & 07777){ /* suid or exe files are selected */
				if ( (st.st_mode & 07777) & (type & 07777) ) ; /* file matches type */
				else continue;
			}
			if ((st.st_mode & S_IFMT)==(type & S_IFMT)) {
				if ((pass=(*(operate))(dirlist.gl_pathv[i]))!=0) break;
			}
		}
	       	globfree(&dirlist);
		if (pass) return (pass);
	}

	
	if (options&RECURSIVE) {
		globstring = (char *)malloc(strlen(path)+3);
		strcpy(globstring,path);
		strcat(globstring,(globstring[strlen(globstring)-1]=='/')?"*":"/*");
		if (glob(globstring,GLOB_ERR|GLOB_ONLYDIR|GLOB_TILDE,NULL,&dirlist) != 0) {
			if (options&VERBOSE) fprintf(stderr,"%s: no match\n",globstring);
		}
		else for (i=0;i<dirlist.gl_pathc;i++) {
			lstat(dirlist.gl_pathv[i],&st);
			if ((st.st_mode & S_IFMT)==S_IFLNK) continue; /* dont follow symlinks */
			if (options&XDEV){
			       if (stinit==NULL) {
			       		stinit=(struct stat *) malloc(sizeof (struct stat));
					lstat(dirlist.gl_pathv[i],stinit);
			       }
				else {
					if (st.st_dev != stinit->st_dev) continue; /* dont leave filesystem */
				}
			}	
			if (options&VERBOSE)fprintf(stderr,"directory: %s \n",dirlist.gl_pathv[i]); 
			pass=globber(dirlist.gl_pathv[i],operate,filter);
			if (pass) break;
		}
		free(globstring);
	       	globfree(&dirlist);
	}
	return (pass);
}



