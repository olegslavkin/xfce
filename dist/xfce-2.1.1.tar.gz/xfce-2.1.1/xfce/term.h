/*
   XPM 
 */
static char *term[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        9            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #615959",
  "a c #fff7f7",
  "b c #ffffff",
  "c c #aaa2a2",
  "d c #183c59",
  "e c #817979",
  "f c #183c59",
  
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "+++++++++++########################+++++++++++++",
  "+++++++++###abbbbbbbbbbbbbbbbbbbbbc###++++++++++",
  "+++++++##acacacacacacaccacacacacacacac##++++++++",
  "++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.#a+++++++",
  "++++++#b...............................#a+++++++",
  "++++++#b...............................#a+++++++",
  "++++++#b.############################b.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#ffffcacfcacfaaccfcacfffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#ffffaaafaccafccaafccaffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#ffffaccfacfccfacfaaccffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#ffffcafaafcacfaccfacfffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#ffffcafacffffffffffffffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#fffffffffffffffffffffffffffb.#a+++++++",
  "++++++#b.#bbbbbbbbbbbbbbbbbbbbbbbbbbbb.#a+++++++",
  "++++++#b...............................#a+++++++",
  "++++++#b...............................#a+++++++",
  "++++++#################################da+++++++",
  "++++++aaaaaaa#######cccccccc######aaaaaaa+++++++",
  "++++++++###########eeeeeeeeee#########a+++++++++",
  "+++++++#aabbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++#aaaa#a#a#a#a#a#aa#a#aaaa#a#a#aa.#a+++++++",
  "+++++#aaa#c#c#c#c#c#c#cc#c#c#caaa#c#c#a.#a++++++",
  "++++#aaaac#c#c#c#c#c#c##c#c#c#caaa#c#caa.#a+++++",
  "+++#aaaa##c#cccccccccccccccc#c#aaaa#c##aa.#a++++",
  "+++daaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a+++",
  "+++dccccccccccccccccccccccccccccccccccccccc#a+++",
  "+++#########################################a+++",
  "+++aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa+++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++"};
