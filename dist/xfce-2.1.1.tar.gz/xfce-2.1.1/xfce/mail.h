/*
   XPM 
 */
static char *mail[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48       11            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #ffffff",
  "a c #615959",
  "b c #fff7f7",
  "c c #0000ff",
  "d c #ff0000",
  "e c #ff6145",
  "f c #aaa2a2",
  "g c #817979",
  "h c #183c59",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "+++++++++++++++++++++++++++++#a+++++++++++++++++",
  "++++++++++++++++++++++++++++#bba++++++++++++++++",
  "+++++++++++++++++++++++++++#bcbba+++++++++++++++",
  "++++++++++++++++++++++++++#bccc.ba++++++++++++++",
  "+++++++++++++++++++++++++#bccccc.ba+++++++++++++",
  "++++++++++++++++++++++++#bdbccccc.ba++++++++++++",
  "+++++++++++++++++++++++#bdbbbcccbb.ba+++++++++++",
  "++++++++++++++++++++++#bdbbdbbcbbbb.ba++++++++++",
  "+++++++++++++++++++++#bebbdbbbbbbbbb.ba+++++++++",
  "++++++++++++++++++++#bbbbdbbbbbbbbbbb.ba++++++++",
  "+++++++++++++++++++#bbbbbbbbbbbbbbbbbb.ba+++++++",
  "++++++#bbbbbbbbbbb#bbbbbbbbbbbbbbbbbbbb.ba++++++",
  "++++++#bfffffffff#bbbbbbbbbbbbbbbbbbbbbb.ba+++++",
  "+++++#bbbbbbbbbb#bbbbbbbbbbbbbbbbbbbbbbbb.fa++++",
  "+++++#bffffffff#bbbbbbbbbbbbbbbbbbbbbbbb.fa+++++",
  "+++++#bbbbbbbb#bbbbbbbbbbbbbbbbbbbfbbbb.faa+++++",
  "+++++#.......#bbbbbbbbbbbbbbbfbbbfgbbb.faga+++++",
  "+++++#......#bbbbbbbbbbfbbbbfgbbfgbbb.fagfa+++++",
  "+++++#.....#bbbbbbbbbbfgbbbfgbbfgbbb.fagffa+++++",
  "+++++#....#bebgfbbbbfgbbbbgbbfgbbbb.fagfffa+++++",
  "+++++#...#bbebgfbbbbgbbbfbbbfgbbbb.fagffffa+++++",
  "+++++#..#bcbebgfbbbbbbbfgbbbgbbbb.fagfffffa+++++",
  "++++a#.#bbcbebgbbbbbbbfgbbbbbbbb.fagffffffab++++",
  "+++a#bffbbcbebbbbbbbbbgbbfbbbbb.fagfffffffa+b+++",
  "++a#.bfffbcbebgfbbbbbbbbfgbbbb.fagffffffffaf+b++",
  "+a#.fgggghfbebgbbbbbbbbbgbbbb.fagfffffggggahf+b+",
  "a#.fgggggghf..bbbbbbbbbbbbbb.fagffffgggggggahf+b",
  "a#.bbbbbbbbbbf.bbbbbbbbbbbb.fagffffbbbbbbbbbbbfb",
  "a#..fffffffffaf.bbbbbbbbbb.fagfffffbffffffggaahb",
  "a#..fffffffffaf..bbbbbbbb.fagffffffbffffffggaahb",
  "a#..fffffffffaf...bbbbbb.fagfffffffbffffffgaaahb",
  "a#..fffffffffahffffffffffagggggggggbffffffggaahb",
  "a#..ffffffffffahffffffffaaaaaaaaaabfffffffgaaahb",
  "a#..fffffffffffaaaaaaaaaaaaaaaaaabffffffffggaahb",
  "a#..fffffffffffbbbbbbbbbbbbbbbbbbfffffffffgaaahb",
  "a#..ffffffffffffffffffffffffffffffffffffffggaahb",
  "a#..fffffffffffffffffffffffffffffffffffffggaaahb",
  "a#..ffffffffffffffffffffffffffffffffffffggggaahb",
  "a#...ffggggggggggggggggggggggggggggggggggaaaaahb",
  "a#..ffggggggggggggggggggggggggggggggggggggaaaahb",
  "ab.ffggggggggggggggggggggggggggggggggggggggaaabb",
  "++bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++"};
