/*
   XPM 
 */
static char *games[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        7            1",
/*
   colors 
 */
  ". m mask c none",
  "# c #615959",
  "a c #ffffff",
  "b c #dfdfdf",
  "c c #615959",
  "d c #aaa2a2",
  "e c #827979",
/*
   pixels 
 */
  "................................................",
  "................................................",
  "..#######################################a......",
  "..#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbb##a......",
  "..#a#########bbbbbbbbb#########bbbbbbbb#aa......",
  "..#a#########bbbbbbbbb#########bbbbbbbb#a.......",
  "..#abbbbbbbbb#########bbbbbbbbb#########a.......",
  "..#abbbbbbbbb#########bbbbbbbbb########aa.......",
  "..#abbbbbbbbb#########bbbbbbbbb########a........",
  "..#abbbbbbbbb#########bbbbbbbbb########a........",
  "..#abbbbbbbbb#########bbbbbbbbb#######aa........",
  "..#abbbbbbbbb########ccccccccccccccc#aa.........",
  "..#abbbbbbbbb#######abbbbbbbcccbbbbbb#..........",
  "..#abbbbbbbbb######cbabbbbbbbcccbbbbbb#.........",
  "..#abbbbbbbbb######cbbaaaaaaaaaaaaaaaaa#........",
  "..#a#########bbbbbbcbbaaadddddddddddddda#.......",
  "..#a#########bbbbbbcbcaadddddddddddddddd##......",
  "..#a#########bbbbbbcccaddd##dddddddd##ddd#c.....",
  "..#a#########bbbbbbcccadd####dddddd####dd#cc....",
  "..#a#########bbbbbbccbadd####dddddd####dd#cce...",
  "..#a#########bbbbbbcbbaddd##dddddddd##ddd#cced..",
  "..#a#########bbbbbbcbbadddddddddddddddddd#cced..",
  "..#a#########bbbbbbcbbadddddddd##dddddddd#ccedd.",
  "..#a#########bbbbbbcbcaddddddd####ddddddd#ccedd.",
  "..#abbbbbbbbb######cccaddddddd####ddddddd#ccedd.",
  "..#abbbbbbbbb######cccadddddddd##dddddddd#ccedd.",
  "..#abbbbbbbbb######ccbadddddddddddddddddd#ccedd.",
  "..#abbbbbbbbb######cbbaddd##dddddddd##ddd#ccedd.",
  "..#abbbbbbbbb#####a#bbadd####dddddd####dd#ccedd.",
  "..#abbbbbbbbb####aa##badd####dddddd####dd#ccedd.",
  "..#abbbbbbbbb###aa...#addd##dddddddd##ddd#ccedd.",
  "..#abbbbbbbbb###a.....#addddddddddddddddd#ccedd.",
  "..#abbbbbbbbb##aa......##ddddddddddddddd##ccedd.",
  "..#############a.........################cccedd.",
  "..aaaaaaaaaaaaaa..........ccccccccccccccccccedd.",
  "...........................cccccccccccccccceedd.",
  "............................eeeeeeeeeeeeeeeeddd.",
  ".............................dddddddddddddddddd.",
  "..............................dddddddddddddddd..",
  "................................................",
  "................................................"};
