

/*
   XPM 
 */
static char *minilock[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    32    24        7            1",
/*
   colors 
 */
  "+ m mask c none",
  "# c #183c59",
  "a c #c7bebe",
  "b c #fff7f7",
  "c c #827979",
  "d c #615959",
  "e c #aaa2a2",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++",
  "+++++++++++++######+++++++++++++",
  "++++++++++++#aaaaaab++++++++++++",
  "+++++++++++#accccccdb+++++++++++",
  "++++++++++#acdddddecdb++++++++++",
  "++++++++++#acdbbbbacdb++++++++++",
  "++++++++++#acdb++#acdb++++++++++",
  "++++++++++#acdb++#acdb++++++++++",
  "++++++++###ecd####acdbbb++++++++",
  "++++++++#aaaaaaaaaaaaaab++++++++",
  "++++++++#aeeeeeeeeeeeedb++++++++",
  "++++++++#aeeaaaaaaaaeedb++++++++",
  "++++++++#aeecccccccceedb++++++++",
  "++++++++#aeeeeeeeeeeeedb++++++++",
  "++++++++#aeeaaaaaaaaeedb++++++++",
  "++++++++#aeecccccccceedb++++++++",
  "++++++++#aeeeeeeeeeeeedb++++++++",
  "++++++++#ddddddddddddddb++++++++",
  "++++++++bbbbbbbbbbbbbbbb++++++++",
  "++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++"};
