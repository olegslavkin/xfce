/*
   XPM 
 */
static char *mininf[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    19    19        4            1",
/*
   colors 
 */
  "+ m mask c none",
  "# c #183c59",
  "a c #ffffff",
  "b c #0000ff",
/*
   pixels 
 */
  "+++++++#####+++++++",
  "+++++##aaaaa##+++++",
  "++++#aabbbbbaa##+++",
  "+++#abbbaaabbbaa+++",
  "++#abbbaaaaabbb#a++",
  "+#abbbbbaaabbbbb#a+",
  "+#abbbbbbbbbbbbb#a+",
  "#abbbbaaaaabbbbbb#a",
  "#abbbbbbaaabbbbbb#a",
  "#abbbbbbaaabbbbbb#a",
  "#abbbbbbaaabbbbbb#a",
  "#abbbbbbaaabbbbbb#a",
  "+#abbbbbaaabbbbb#a+",
  "+#abbbbbaaabbbbb#a+",
  "++#abbaaaaaaabb#a++",
  "+++a#bbbbbbbbb#a+++",
  "++++a##bbbbb##a++++",
  "+++++aa#####aa+++++",
  "+++++++aaaaa+++++++"};
