/*
   XPM 
 */
static char *print[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48       10            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #aaa2a2",
  "a c #fff7f7",
  "b c #ffffff",
  "c c #615959",
  "d c #183c59",
  "e c #817979",
  "f c #00ff00",
  "g c #ff6145",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "+++++++++++######################+++++++++++++++",
  "+++++++++++abbbbbbbbbbbbbbbbbbbba+++++++++++++++",
  "+++++++++++abbbbbbbbbbbbbbbbbbbba+++++++++++++++",
  "+++++++++++abbbbbbbbbbbbbbbbbbbba+++++++++++++++",
  "+++++++ccccabbbbbbbbbbbbbbbbbbbbacccccccca++++++",
  "++++++cb...abbbbbbbbbbbbbbbbbbbba........da+++++",
  "+++++cb...eabbbbbbbbbbbbbbbbbbbba.........da++++",
  "++++cb...e#aaaaaaaaaaaaaaaaaaaaaa..........da+++",
  "+++cb...dceeeeeeeeeeeeeeeeeeeeeeee..........da++",
  "+++cbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbda++",
  "+++cbaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaada++",
  "+++cb..eeeeeeeeeeeeeeeeeeeeeeeeeeeecccccccc.da++",
  "+++cb..eeeeeeeeeeeeeeeeeeeeeeeeeeeceffeeggc.da++",
  "+++cb..eaaaaaaaaaaaaaaaaaaaaaaaaaaceffeeggc.da++",
  "+++cb..eeeeeeeeeeeeeeeeeeeeeeeeeeeccccccccc.da++",
  "+++cb.......................................da++",
  "+++cb.......................................da++",
  "+++cb.##############################eee#ee#.da++",
  "+++cb.###############################ee#ee#.da++",
  "+++cb.......................................da++",
  "+++cb...eeeeeeeeeeeeeeeeeeeeeeeeeeee........da++",
  "+++cb...edddddddddddddddddddddddddd.........da++",
  "+++cb...ed#eeeeeeeeeeeeeeeeeeeeeeedd........da++",
  "+++cbdddd#eeeeeeeeeeeeeeeeeeeeeeeeedddddddddda++",
  "+++caaadd##########################ddddddddaaa++",
  "+++++cadd#eeeeeeeeeeeeeeeeeeeeeeeeedddddddda++++",
  "+++++caad#eeeeeeeeeeeeeeeeeeeeeeeeedcaaaaaaa++++",
  "+++++++#ddddddddddddddddddddddddddddc#++++++++++",
  "++++++++#cccccccccccccccccccccccccccc##+++++++++",
  "+++++++++###############################++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++"};
