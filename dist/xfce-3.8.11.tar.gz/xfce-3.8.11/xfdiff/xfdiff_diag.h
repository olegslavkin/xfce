 /* xfdiff_diag.h */

/* function prototypes: */

void show_diag (gchar * message);
void hide_diag (void);
