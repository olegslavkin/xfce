/* XPM */
static char *games[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        6            1",
/*
   colors 
 */
  ". m mask c none",
  "# c #595959",
  "a c #ffffff",
  "b c #dfdfdf",
  "c c #a2a2a2",
  "d c #797979",
/*
   pixels 
 */
  "................................................",
  "................................................",
  "..#######################################a......",
  "..#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbbb#a......",
  "..#a#########bbbbbbbbb#########bbbbbbbb##a......",
  "..#a#########bbbbbbbbb#########bbbbbbbb#aa......",
  "..#a#########bbbbbbbbb#########bbbbbbbb#a.......",
  "..#abbbbbbbbb#########bbbbbbbbb#########a.......",
  "..#abbbbbbbbb#########bbbbbbbbb########aa.......",
  "..#abbbbbbbbb#########bbbbbbbbb########a........",
  "..#abbbbbbbbb#########bbbbbbbbb########a........",
  "..#abbbbbbbbb#########bbbbbbbbb#######aa........",
  "..#abbbbbbbbb########################aa.........",
  "..#abbbbbbbbb#######abbbbbbb###bbbbbb#..........",
  "..#abbbbbbbbb#######babbbbbbb###bbbbbb#.........",
  "..#abbbbbbbbb#######bbaaaaaaaaaaaaaaaaa#........",
  "..#a#########bbbbbb#bbaaacccccccccccccca#.......",
  "..#a#########bbbbbb#b#aacccccccccccccccc##......",
  "..#a#########bbbbbb###accc##cccccccc##ccc##.....",
  "..#a#########bbbbbb###acc####cccccc####cc###....",
  "..#a#########bbbbbb##bacc####cccccc####cc###d...",
  "..#a#########bbbbbb#bbaccc##cccccccc##ccc###dc..",
  "..#a#########bbbbbb#bbacccccccccccccccccc###dc..",
  "..#a#########bbbbbb#bbacccccccc##cccccccc###dcc.",
  "..#a#########bbbbbb#b#accccccc####ccccccc###dcc.",
  "..#abbbbbbbbb#########accccccc####ccccccc###dcc.",
  "..#abbbbbbbbb#########acccccccc##cccccccc###dcc.",
  "..#abbbbbbbbb########bacccccccccccccccccc###dcc.",
  "..#abbbbbbbbb#######bbaccc##cccccccc##ccc###dcc.",
  "..#abbbbbbbbb#####a#bbacc####cccccc####cc###dcc.",
  "..#abbbbbbbbb####aa##bacc####cccccc####cc###dcc.",
  "..#abbbbbbbbb###aa...#accc##cccccccc##ccc###dcc.",
  "..#abbbbbbbbb###a.....#accccccccccccccccc###dcc.",
  "..#abbbbbbbbb##aa......##ccccccccccccccc####dcc.",
  "..#############a.........###################dcc.",
  "..aaaaaaaaaaaaaa..........##################dcc.",
  "...........................################ddcc.",
  "............................ddddddddddddddddccc.",
  ".............................cccccccccccccccccc.",
  "..............................cccccccccccccccc..",
  "................................................",
  "................................................"};
