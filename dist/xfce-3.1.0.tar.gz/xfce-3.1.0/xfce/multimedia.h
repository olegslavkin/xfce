/* XPM */
static char *multimedia[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        8            1",
/*
   colors 
 */
  ". m mask c none",
  "# c #183c59",
  "a c #ffffff",
  "b c #a2a2a2",
  "c c #595959",
  "d c #0000ff",
  "e c #797979",
  "f c #bebebe",
/*
   pixels 
 */
  "................................................",
  "................................................",
  "........#####################################a..",
  "........#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a..",
  "........#abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb#a..",
  "........#abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb#a..",
  "........#abbccccccccccccccccccccccccccccc#bb#a..",
  "........#abb#dcdcdcdcdcdcdcdcdcdcdcdcdcdcabb#a..",
  "........#abb#cccccececececececececececcccabb#a..",
  "......aa#abb#dcdedededededededededededcdcabb#a..",
  ".....aea#abb#cceeeeeeeeeeeeeeeeeeeeeee#ccabb#a..",
  "....ae###abb#dcdededbdbdbdbdbdbdbdededcdcabb#a..",
  "...aeec##abb#ceeebbbbbbbbbbbbbbbbbbbeeeccabb#a..",
  "..aeffec##bb#dcdedbdbdbdbdbdbdbdbdbdedcdcabb#a..",
  "..aaafbec##b#ceebbbbbbbbbbbbbbbbbbbbbeeccabb#a..",
  ".....afbec###dcdedbdbdfdfdfdfdfdbdbdedcdcabb#a..",
  "......afbec##ceebbbbbfffffffffffbbbbbeeccabb#a..",
  ".......afbec##cdedbdbdfdfdfdfdfdbdbdedcdcabb#a..",
  "........afbec##ebbbbbfffffffffffbbbbbeeccabb#a..",
  "........#afbec##edbdbdfdfdfdfdfdbdbdedcdcabb#a..",
  "........#aafbec##bbbbbbbbbbbbbbbbbbbeeeccabb#a..",
  "........#abafbec##bdbdbdbdbdbdbdbdbdedcdcabb#a..",
  "........#abbafbec##ebebebebebebebeeeeeeccabb#a..",
  "........#abb#afbec##edededededededededcdcabb#a..",
  "......aaaaaaaaaaaaaaaaaaaaaaaaaaeeeeeecccabb#a..",
  "....aaafffffffffffffffffffffffffaacdcdcdcabb#a..",
  "...aafffbbbbbbbbbbbbbbbbbbbbbbbbbbaa#ccccabb#a..",
  "...affeeeeeeeeeeeeeeeeeeeeeeeeeafffffff#aabb#a..",
  "...afbbbbbeeeeeeeeeeeeeeeeeeeeafbbbbbbb#cbbb#a..",
  "...afbeeeceeebbbbbbbbbbbbbbbbeffbbbbbbb##ebb#a..",
  "...afbcccceeebeeeeeeeeeeeeeecebbeeeeeee##eb##a..",
  "...afbbbbbeeebeeeeeeeeeeeeeecebbeeeeeee##ebaaa..",
  "...afbeeeceeebeeffffffffffeeceeeccccccc##eb.....",
  "...afbcccceeebeeffbbffbbffeecececcccccc#ceb.....",
  "...afbbbbbeeebeefbbbffbbbfeeceec########ceb.....",
  "...afbeeeceeebeeffbbffbbffeeceeeeecc#cccceb.....",
  "...afbcccceeebeeeeeeeeeeeeeeceeeeecc#cccceb.....",
  "...afbeeeeeeecccccccccccccccceeeeccc#cceeeb.....",
  "...afbccccccccccccccccccccccccccccc##ccebbb.....",
  "....acccccccccccccccccccccccccccccc#cccebbb.....",
  ".....###############################cccebb......",
  "......c##########################ccccceebb......",
  ".......cccccccccccccccccccccccccccccccebbb......",
  "........ccccccccccccccccccccccccccceeeebbb......",
  ".........eeeeeeeeeeeeeeeeeeeeeeeeeeebbbbb.......",
  "..........bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.......",
  "...........bbbbbbbbbbbbbbbbbbbbbbbbbbb..........",
  "................................................"};
