/* XPM */
static char *minbutdn[] = {
  "11 6 4 1",
  ". c none",
  "X c #f0f0f0",
  "o c #303030",
  "+ c yellow",
  "ooooooooooo",
  ".o+++++++X.",
  "..o+++++X..",
  "...o+++X...",
  "....o+X....",
  ".....o....."
};
