static char *handle[] = {
  "94 10 3 1",
  ". c none",
  "X c #d0d0d0",
  "o c #303030",
  "oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo..oo",
  "X..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX.",
  "..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..",
  ".oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..o",
  "oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX",
  "X..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX.",
  "..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..",
  ".oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..o",
  "oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX..oX",
  "X..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX..XX."
};
