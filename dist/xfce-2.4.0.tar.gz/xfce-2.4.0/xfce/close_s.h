/*
   XPM 
 */
static char *close_s[] =
{
/**/
"6 3 3 1",
/**/
  " 	s mask	c none",
  "X      c #303030",
  "o      c #ffffff",
  "XXXXXo",
  "X    o",
  "Xooooo"};
