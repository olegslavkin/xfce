
/*
   XPM 
 */
static char *iconify_s[] =
{
/**/
"3 3 3 1",
/**/
  " 	s mask	c none",
  "X      c #303030",
  "o      c #ffffff",
  "XXo",
  "X o",
  "Xoo"};
