/* XPM */
static char *handle_s[] =
{
/**/
"30 8 3 1",
/**/
  " 	s mask	c none",
  "X      c #ffffff",
  "o      c #303030",
  "oo  oo  oo  oo  oo  oo  oo  oo",
  "oX  oX  oX  oX  oX  oX  oX  oX",
  "oX  oX  oX  oX  oX  oX  oX  oX",
  "oX  oX  oX  oX  oX  oX  oX  oX",
  "oX  oX  oX  oX  oX  oX  oX  oX",
  "oX  oX  oX  oX  oX  oX  oX  oX",
  "oX  oX  oX  oX  oX  oX  oX  oX",
  "XX  XX  XX  XX  XX  XX  XX  XX"};
