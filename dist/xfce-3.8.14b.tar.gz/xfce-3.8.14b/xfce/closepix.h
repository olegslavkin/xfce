/* XPM */
static char *closepix[] = {
  "6 3 3 1",
  ". c none",
  "X c #303030",
  "o c #f0f0f0",
  "XXXXXo",
  "X....o",
  "Xooooo"
};
