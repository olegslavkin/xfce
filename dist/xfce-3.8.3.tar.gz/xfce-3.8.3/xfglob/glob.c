
/* glob.c file filter for grep.*/
/* 
   Copyright 2000 Edscott Wilson Garcia

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA.  */

/*****************************************************************/
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#ifndef HAVE_SNPRINTF
#  include "snprintf.h"
#endif

#ifdef DMALLOC
#  include "dmalloc.h"
#endif

#define VERSION_NAME "\nglob 0.3.3\n\nCopyright 2000-2001 Edscott Wilson Garcia\n\
This is free software; see the source for copying conditions. There is NO\n\
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n"

#include <signal.h>
#include <time.h>
#include "globber.h"
#define GREP "grep"

/* watch out for values #defined in globber.h */
#define NOBINARIES 0x10000


static int initial;
static int terminated = 0;
static char *token;
#define MAX_ARG 25
static int
display (char *input)
{
  if (terminated)
    return terminated;		/* die quietly and quickly */
  printf ("%s\n", input);
  if (time (NULL) - initial > 3)
    {
      fflush (NULL);
      initial = time (NULL);
    }
  return terminated;
}
static int
grep (char *file)
{
  static char *arguments[MAX_ARG];
  int status = 0;
  if (terminated)
    return terminated;		/* die quietly and quickly */

  arguments[status++] = "grep";
  arguments[status++] = "--d";
  arguments[status++] = "skip";
  arguments[status++] = "-H";
  if (options & NOBINARIES)
    arguments[status++] = "-I";
  if (options & IGNORE_CASE)
    arguments[status++] = "-i";
  if (options & WORDS_ONLY)
    arguments[status++] = "-w";
  if (options & LINES_ONLY)
    arguments[status++] = "-x";
  if (options & ZERO_BYTE)
    arguments[status++] = "-Z";

  if ((options & COUNT) && (options & INVERT))
    {
      arguments[status++] = "-c";
      arguments[status++] = "-v";
    }
  if ((options & COUNT) && !(options & INVERT))
    {
      arguments[status++] = "-c";
    }
  if (!(options & COUNT) && (options & INVERT))
    {
      arguments[status++] = "-L";
    }
  if (!(options & COUNT) && !(options & INVERT))
    {
      arguments[status++] = "-l";
    }

  if (options & REG_EXP)
    arguments[status++] = "-E";
  else
    arguments[status++] = "-e";
  arguments[status++] = token;

  arguments[status++] = file;
  arguments[status++] = (char *) 0;
  if (options & VERBOSE)
    {
      int i;
      for (i = 0; i < status; i++)
	printf ("%s ", arguments[i]);
      printf ("\n");
    }

  if (fork () == 0)
    execvp (GREP, arguments);
  wait (&status);

  /*fflush(NULL); */
  return terminated;
}


static char *message[] = {
  " [options] path...\n\n",
  "options: \n"
    "          [-r] [-v] [-d ddd] [-m mmm] [-f filter] [-s (+/-)size]\n",
  "          [-t type] [-p perm] [grep options...] \n",
  "-v            = verbose\n",
  "-V            = print version number information\n",
  "-P            = print process id (capital P)\n",
  "-f filter     = file filter (enclosed in quotes if regexp *,? or\n",
  "                [] is used)\n",
  "-r            = recursive\n",
  "-s +kbytes    = size greater than kbytes KBYTES\n",
  "-s -kbytes    = size less than kbytes KBYTES\n",
  "-p perm       = perm is either suid | exe\n",
  "-t type       = reg | dir | sym | sock | blk | chr | fifo\n",
  "                (regular, directory, symlink, socket, blk_dev,\n",
  "                 chr_dev, fifo)\n",
  "-h hhh        = created or modified in the previous (int) hh hours\n",
  "-d ddd        = created or modified in the previous (int) dd days\n",
  "-m mmm        = created or modified in the previous (int) mm months\n"
    "\n",
  "grep options:\n",
  "-a            = stay on a single filesystem.\n",
  "-e string     = containing string (if *,? or [], use quotes)\n",
  "-E regexp     = containing regexp: (use quotes amigo). \n",
  "-i            = ignore case (for search string -c)\n",
  "-I            = do not search into binary files\n",
  "-y            = same as -i (obsolete)\n",
  "-u user-id    = only files matching numeric user-id\n",
  "-g group-id   = only files matching numeric group-id\n",
  "-L            = print the  name  of each input file from which *no*\n",
  "                output would normally have been printed.\n",
  "-c            = only print a count of matching lines for each input\n",
  "                file.\n",
  "-w            = Select  only  those  lines  containing matches that\n",
  "               form whole words. Word-constituent  characters  are\n",
  "               letters, digits, and the underscore.\n",
  "-x            = Select only those matches that  exactly  match  the\n",
  "                whole line.\n",
  "-Z            = Output  a  zero  byte  (the  ASCII  NUL  character)\n",
  "                instead of the character that  normally  follows  a\n",
  "                file  name\n",
  "\n",
  NULL
};

void
finish (int sig)
{
  /*printf("\n****\nglob terminated by signal\n****\n"); */
  terminated = 1;
  fflush (NULL);
}

void
halt (int sig)
{
  fflush (NULL);
  exit (1);
}

int
main (int argc, char **argv)
{
  int i;
  char *filter = NULL, globbered = 0;
  int (*operate) (char *) = display;
  initial = time (NULL);

  /* initialization for globber */
  signal (SIGHUP, halt);
  signal (SIGSEGV, finish);
  signal (SIGKILL, finish);
  signal (SIGTERM, finish);

  month_t = day_t = hour_t = size = options = 0x0;
  type = S_IFREG;
  if (argc < 2)
    {
    error:
      fprintf (stderr, "use:  %s ", argv[0]);
      i = 0;
      while (message[i])
	printf ("%s", message[i++]);
      exit (1);
    }

  for (i = 1; i < argc; i++)
    {
      if (argv[i][0] == '-')
	{
	  if (strstr (argv[i], "a") != NULL)
	    {
	      options |= XDEV;
	      continue;
	    }
	  if (strstr (argv[i], "v") != NULL)
	    {
	      options |= VERBOSE;
	      continue;
	    }
	  if (strstr (argv[i], "I") != NULL)
	    {
	      options |= NOBINARIES;
	      continue;
	    }
	  if (strstr (argv[i], "r") != NULL)
	    {
	      options |= RECURSIVE;
	      continue;
	    }
	  if (strstr (argv[i], "i") != NULL)
	    {
	      options |= IGNORE_CASE;
	      continue;
	    }
	  if (strstr (argv[i], "y") != NULL)
	    {
	      options |= IGNORE_CASE;
	      continue;
	    }
	  if (strstr (argv[i], "L") != NULL)
	    {
	      options |= INVERT;
	      continue;
	    }
	  if (strstr (argv[i], "c") != NULL)
	    {
	      options |= COUNT;
	      continue;
	    }
	  if (strstr (argv[i], "w") != NULL)
	    {
	      options |= WORDS_ONLY;
	      continue;
	    }
	  if (strstr (argv[i], "x") != NULL)
	    {
	      options |= LINES_ONLY;
	      continue;
	    }
	  if (strstr (argv[i], "Z") != NULL)
	    {
	      options |= ZERO_BYTE;
	      continue;
	    }
	  if (strstr (argv[i], "P") != NULL)
	    {
	      options |= PID;
	      printf ("PID=%d\n", (int) getpid ());
	      fflush (NULL);
	      continue;
	    }
	  if (strstr (argv[i], "u") != NULL)
	    {
	      i++; /* caveat, add one */
	      GLOBBER_user = atol(argv[i])+1;
	      continue;
	    }
	  if (strstr (argv[i], "g") != NULL)
	    {
	      i++; /* caveat, add one */
	      GLOBBER_group = atol(argv[i])+1;
	      continue;
	    }
	  if (strstr (argv[i], "E") != NULL)
	    {
	      i++;
	      token = argv[i];
	      operate = grep;
	      options |= REG_EXP;
	      continue;
	    }
	  if (strstr (argv[i], "e") != NULL)
	    {
	      i++;
	      token = argv[i];
	      operate = grep;
	      options |= REG_EXP;
	      options ^= REG_EXP;	/* always turn off regexp */
	      continue;
	    }


	  if (strstr (argv[i], "t") != NULL)
	    {
	      i++;
	      type &= 07777;
	      if (strcmp (argv[i], "reg") == 0)
		type |= S_IFREG;	/*default */
	      if (strcmp (argv[i], "dir") == 0)
		type |= S_IFDIR;
	      if (strcmp (argv[i], "sym") == 0)
		type |= S_IFLNK;
	      if (strcmp (argv[i], "sock") == 0)
		type |= S_IFSOCK;
	      if (strcmp (argv[i], "blk") == 0)
		type |= S_IFBLK;
	      if (strcmp (argv[i], "chr") == 0)
		type |= S_IFCHR;
	      if (strcmp (argv[i], "fifo") == 0)
		type |= S_IFIFO;
	      continue;
	    }

	  if (strstr (argv[i], "p") != NULL)
	    {
	      i++;
	      type &= S_IFMT;
	      if (strcmp (argv[i], "suid") == 0)
		type |= S_ISUID;
	      if (strcmp (argv[i], "exe") == 0)
		type |= S_IXUSR;
	      continue;
	    }


	  if (strstr (argv[i], "s") != NULL)
	    {
	      i++;
	      size = atol (argv[i]);
	      size *= 1024;
	      continue;
	    }

	  if (strstr (argv[i], "h") != NULL)
	    {
	      i++;
	      hour_t = atol (argv[i]);
	      continue;
	    }
	  if (strstr (argv[i], "d") != NULL)
	    {
	      i++;
	      day_t = atol (argv[i]);
	      continue;
	    }
	  if (strstr (argv[i], "m") != NULL)
	    {
	      month_t = atol (argv[i]);
	      continue;
	    }

	  if (strstr (argv[i], "f") != NULL)
	    {
	      options |= FILTERED;
	      i++;
	      filter = argv[i];
	      if (options & VERBOSE)
		fprintf (stderr, "filtering %s\n", filter);
	      continue;
	    }
	  if (strstr (argv[i], "V") != NULL)
	    {
	      printf ("%s", VERSION_NAME);
	      return 0;
	    }
	  goto error;
	}
      if (!(type & S_IFMT))
	type |= S_IFREG;
      terminated = globber (argv[i], operate, filter);
      globbered = 1;
    }
  if (!globbered)
    {
      fprintf (stderr, "must specify path\n");
      goto error;
    }
/*	if (terminated) printf("glob run was terminated.\n");*/
  if (!terminated)
    {				/* die quietly and quickly */
      if (options & PID)
	printf ("GLOB DONE=%d\n", (int) getpid ());
    }
  fflush (NULL);
  exit (0);
}
