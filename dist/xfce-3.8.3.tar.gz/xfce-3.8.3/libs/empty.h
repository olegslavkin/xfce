/* XPM */
static char *empty[] = {
  "2 2 1 1",
  ". c none",
  "..",
  ".."
};
