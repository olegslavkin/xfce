/* XPM */
static char *addiconpix[] = {
  "16 16 3 1",
  ". c none",
  "X c #f0f0f0",
  "o c #303030",
  "oooooooooooooooX",
  "o..............X",
  "o..............X",
  "o...oooooooo...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...o......X...X",
  "o...XXXXXXXX...X",
  "o..............X",
  "o..............X",
  "oXXXXXXXXXXXXXXX"
};
