/*
   XPM 
 */
static char *paint[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48       13            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #183c59",
  "a c #615959",
  "b c #fff7f7",
  "c c #aaa2a2",
  "d c #ffffff",
  "e c #ff6145",
  "f c #ff00ff",
  "g c #817979",
  "h c #ffff00",
  "i c #0000ff",
  "j c #00ff00",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++++",
  "+++++++#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa+++++++",
  "+++++++#bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb+++++++",
  "+++++++#bccccccccccccccccccccccccccdddddd#b+++++++",
  "+++++++#bcccccccccccccccccccccccddd......ddd++++++",
  "+++++++#bccbbbbbbbbbbbbbbbbbbbdd......eee...ddd+++",
  "+++++++#bccbcccccccccc#bccccdd.......eeeee.....dc+",
  "+++++++#bccbcccccccccc#bcccd...fff...eeeee.....#c+",
  "+++++++#bccbcccccccccc#bccd...fffff...eee.....#cc+",
  "+bbbbbbbbccbccbbbbbbcc#bcd....fffff..........#cc++",
  "+cccccccc#cbccbccccgcc#bd......fff..........#cc+++",
  "+ccccccccc#bccggggggcc#bd..................#cc++++",
  "+######ccc#bcccccccccc#bd..hhh.............bbbbb++",
  "+++++++bcc#bcccccccccc#bd.hhhhh........iii.....#c+",
  "+++++++bcc#b###########bd.hhhhh..jjj..iiiii....#c+",
  "+++++++bcc#b............d..hhh..jjjjj.iiiii...##c+",
  "+++++++bcc#bccccccccccccg##.....jjjjj..iii...##cc+",
  "++bbbbbbbbbbbbbbbccccccccg###....jjj........##cc++",
  "++b..............#ccccccccgg###c..........##ccc+++",
  "++b.bbbcbbbcbbbcc#acccccccccgg############ccc+++++",
  "++b.bbbabbbabbbac#agccbbbbbbbbbbbbbgggggg#cc++++++",
  "++b.bbbabbbabbbac#agccbbbbbbbbbbbbb#ggggc#b+++++++",
  "++b.bbbabbbabbbac#agccbb###bbb###bb#gcccc#b+++++++",
  "++b.bbbabbbabbbac#agccbb#ggbbb#ggbb#gcccc#b+++++++",
  "++bgggggggggggggc#agcc###gcbbb#cc###gcccc#b+++++++",
  "++b.............c#agcccgggcbbb#cccgggcccc#b+++++++",
  "++b.b.b.b.b.b.b.c#agcccccccbbb#cbbbbbbbbc#b+++++++",
  "++bbbbbbbbbbbbbbc#agcccccccbbb#cb##bb##bg#b+++++++",
  "++bbbbbbbbbbbbbbc#agcccccccbbb#cb#gbb#gbg#b+++++++",
  "++b.b.b.b.b.b.b.c#ag#######bbb#####bb#####b+++++++",
  "++b.............c#acbbbbbbbbbb#bbbbbb#bbbbb+++++++",
  "++b.............c#ac+++++++bbb#c+++bb#c+++++++++++",
  "++b.c.c.c.c.c.c.c#ac+++++++bbb#c+++bb#c+++++++++++",
  "++bcccccccccccccc#ac+++++bbbbbbb+++bb#c+bbbbb+++++",
  "++bcccccccccccccc#ac+++++bbbbbbb#++bb#c+b#b#b#++++",
  "++bgcgcgcgcgcgcgc#ac++++++#######c+bb#c+##b###c+++",
  "++bgggggggggggggg#ac+++++++cccccccbbbb#c++b#ccc+++",
  "++bgggggggggggggg#ac+++++++++++++++####c++b#c+++++",
  "++bgggggggggggggg#ac++++++++++++++++cccc++b#c+++++",
  "+++###############ac+++++++++++++++++++++bbb#+++++",
  "++++aaaaaaaaaaaaaacc++++++++++++++++++++++###c++++",
  "+++++cccccccccccccc++++++++++++++++++++++++ccc++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++++"};
