/*
   XPM 
 */
static char *file2[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48       11            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #aaa2a2",
  "a c #183c59",
  "b c #615959",
  "c c #ffffff",
  "d c #ff00ff",
  "e c #817979",
  "f c #fff7f7",
  "g c #0000ff",
  "h c #00ff00",
/*
   phxels 
 */
  "+++++++++++++++++++............+++++++++++++++++",
  "+++++++++#####a++++.##########ab+++++++++cddb#++",
  "+++++++++e#fffab+++.baaaaaaaa#ab#+++++++cdddab#+",
  "+++++++++#ffffab#++.bagagaga.#ab#++++++cddddab#+",
  "+++++++++e##ffab#++.bagagaag.#ab#+++++cahddab#++",
  "+++++++++#ffffab#++.ba.......#ab#++++chfahab#+++",
  "++bbbbbbbe#fffabbbb.b#.##.##.#abbbbbchhhfbb#++++",
  "++bbbbbbb#ffffabbbb.b..b..b..#abbbbchhhfbb#+++++",
  "++bbbbbbbe##ffabbbb.bbbbbbbbb#abbbchhhfab#++++++",
  "++bbbbbbb#ffffabbbb.b#.##.##.#abbchhhfab#+++++++",
  "++b#bbbbbe#fffabbbb.b..b..b..#abchhhfab#++++++++",
  "++b##bbbb#ffffabbbb.bbbbbbbbb#achhhfabb+++++++++",
  "++b###bbbe##ffabbbb.b#########aaaaaabbb+++++++++",
  "++b##fffffffffffffffffffffffffffffffffffff++++++",
  "++b##f###################################a++++++",
  "++b##f###################################a++++++",
  "++bb#f###################################a++++++",
  "++bbbf###################################a++++++",
  "++bbbf###################################a++++++",
  "++bbbf###################################a++++++",
  "++bbbf##########ccccccccccccccc##########a#+++++",
  "++b#bf##########c#############cb#########a##++++",
  "++b##f##########c#hhhhhhhhhhhhcb#########a###+++",
  "++b##f##########c#hhhhhhhhhhhhcb#########ab###++",
  "++b##f##########c#hhhhhhhhhhhhcb#########abb###+",
  "++b##f##########caaaaaaaaaaaaacb#########abbb##+",
  "++b##f##########cabbbbbbbbbbbbcb#########abbb##+",
  "++bb#f##########ca############cb#########abbb##+",
  "++bbbf##########cccccccccccccccb#########abbb##+",
  "++bbbf###########bbbbbbbbbbbbbbb#########abbb##+",
  "++bbbf###################################abbb##+",
  "++bbbf###################################abbb##+",
  "++b#bf###################################abbb##+",
  "++b##f###################################abbb##+",
  "++b##f###################################abbb##+",
  "++b##f###################################abbb##+",
  "++b##f###################################abbb##+",
  "+++##f###################################abbb##+",
  "++++#f###################################abbb##+",
  "+++++f###################################abbb##+",
  "+++++f###################################abbb##+",
  "+++++f###################################abbb##+",
  "+++++faaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabbb##+",
  "+++++++++###bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb##+",
  "++++++++++###bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb##+",
  "+++++++++++###bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb##+",
  "++++++++++++###################################+",
  "+++++++++++++##################################+"};
