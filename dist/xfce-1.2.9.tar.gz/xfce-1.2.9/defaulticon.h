/*
   XPM 
 */
static char *defaulticon[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    38    28        6            1",
/*
   colors 
 */
  ". c #615959",
  "# c #ffffff",
  "a c #e7dfdf",
  "b c #817979",
  "c c #beb6b6",
  "d c #5151fb",
/*
   pixels 
 */
  ".....................................#",
  ".###################################.#",
  ".#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.#",
  ".#accccccccccccccccccccccccccccccccb.#",
  ".#bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.#",
  ".....................................#",
  ".###################################.#",
  ".#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.#",
  ".#abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbab.#",
  ".#abccccccccccccccccccccccccccccccab.#",
  ".#abcccccccccddddcccccccddccccccccab.#",
  ".#abccccccccccddddcccccddcccccccccab.#",
  ".#abcccccccccccddddcccddccccccccccab.#",
  ".#abcccccccccccddddccddcccccccccccab.#",
  ".#abccccccccccccddddddccccccccccccab.#",
  ".#abcccccccccccccddddcccccccccccccab.#",
  ".#abccccccccccccccddddccccccccccccab.#",
  ".#abcccccccccccccdddddccccccccccccab.#",
  ".#abccccccccccccddcddddcccccccccccab.#",
  ".#abcccccccccccddcccddddccccccccccab.#",
  ".#abccccccccccddcccccddddcccccccccab.#",
  ".#abcccccccccddccccccddddcccccccccab.#",
  ".#abccccccccddccccccccddddccccccccab.#",
  ".#abccccccccccccccccccccccccccccccab.#",
  ".#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.#",
  ".#bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.#",
  ".....................................#",
  "######################################"};
