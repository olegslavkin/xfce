/*
   XPM 
 */
static char *close[] =
{
/**/
"8 4 3 1",
/**/
  " 	s mask	c none",
  "X      c #ffffff",
  "o      c #303030",
  "XXXXXXXo",
  "X      o",
  "X      o",
  "Xooooooo"};
