make -f Makefile.init
