Maurizio Porrato <mporrato@edu.al.unipmn.it> has submitted a very interresting
Python script :

---------------------------------------------------------------------
The attached file is a simple python script I wrote last weekend.
It reads Xfce's color settings and modifies the X resources database
accordingly. It works in a way similar to CDE and KDE >= 1.1, giving
a more uniform environment.
I put this script in ~/Desktop/Autostart/ and set the x bit, so it is
run automatically at startup.
---------------------------------------------------------------------
