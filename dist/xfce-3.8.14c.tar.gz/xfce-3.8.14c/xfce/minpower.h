/* XPM */
static char *minpower[] = {
/* width height num_colors chars_per_pixel */
  "    14    16        4            1",
/* colors */
  ". c none",
  "# c #595959",
  "a c #183c59",
  "b c #fff7f7",
/* pixels */
  ".....###b.....",
  ".....#aab.....",
  ".....#aab.....",
  "..##b#aab###..",
  ".#aab#aab#aab.",
  "#aaab#aab#aaab",
  "#aab.#aab.#aab",
  "#aab.#aab.#aab",
  "#aab.bbbb.#aab",
  "#aab......#aab",
  "#aab......#aab",
  "#aaab....#aaab",
  ".#aaa####aaab.",
  ".#aaaaaaaaaab.",
  "..bbaaaaaabb..",
  "....bbbbbb...."
};
