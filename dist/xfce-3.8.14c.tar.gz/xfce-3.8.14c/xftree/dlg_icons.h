/* icons for dlg routines */
#ifndef __DLG_ICONS_H__
#define __DLG_ICONS_H__
#include "icons/warning.xpm"
#include "icons/info.xpm"
#include "icons/question.xpm"
#include "icons/error.xpm"
#endif
