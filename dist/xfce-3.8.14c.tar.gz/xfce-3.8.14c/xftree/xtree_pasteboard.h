/*
 * Edscott Wilson Garcia Copyright 2001-2002 GNU-GPL
*/
#define XFTREE_PASTEBOARD "xftree.pb"

void cb_clean_pasteboard(GtkWidget * widget, GtkCTree * ctree);
void cb_copy(GtkWidget * widget, GtkCTree * ctree);
void cb_cut(GtkWidget * widget, GtkCTree * ctree);
void cb_paste(GtkWidget * widget, GtkCTree * ctree);
void cb_paste_show(GtkWidget * widget, GtkCTree * ctree);


