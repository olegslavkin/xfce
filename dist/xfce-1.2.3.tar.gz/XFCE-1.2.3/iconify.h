/* XPM */
static char * iconify [] = {
/**/
"4 4 3 1",
/**/
" 	s mask	c none",
"X      c #ffffff",
"o      c #303030",
"XXXo",
"X  o",
"X  o",
"Xooo"};

