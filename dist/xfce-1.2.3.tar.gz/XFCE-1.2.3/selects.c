/*

 ORIGINAL FILE NAME : selects.c

 ********************************************************************
 *                                                                  *
 *           X F C E  - Written by O. Fourdan (c) 1997              *
 *                                                                  *
 *           This software is absolutely free of charge             *
 *                                                                  *
 ********************************************************************

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT.  IN NO EVENT SHALL THE AUTHOR (O. FOURDAN) BE 
  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/



#include "selects.h"
#include "extern.h"
#include "XFCE.h"

/* Load pixmap files */
#include "file1.h"
#include "file2.h"
#include "mail.h"
#include "write.h"
#include "term.h"
#include "man.h"
#include "paint.h"
#include "print.h"
#include "multimedia.h"
#include "games.h"
#include "schedule.h"

static char * icon_name[] = {
    "Files related",
    "Terminals/Connections",
    "Mail tools/browsers",
    "Print manager",
    "Configuration",
    "Misc. tools/Utilities",
    "Manual/Help browser",
    "Writing/Text tools",
    "Schedule/Appointments",
    "Multimedia",
    "Games"};

static char ** icon_data[] = {
    file1,
    term,
    mail,
    print,
    paint,
    file2,
    man,
    write,
    schedule,
    multimedia,
    games};

void alloc_selects(void)
{
   int i;
   
   for(i=0; i<NBSELECTS+1; i++)
       selects[i].command = (char *) malloc ((MAXSTRLEN+1) * sizeof(char));
}

void free_selects(void)
{
   int i;
    
   for(i=0; i<NBSELECTS+1; i++) free(selects[i].command);
}

int load_icon_str(char *str)
{
    char * a;
    int i, error = 0;

    if (a=strtok(str, ",")) {
        selects[0].icon_nbr=atoi(a);
        for(i=1; i<NBSELECTS; i++) 
            if (a=strtok(NULL,",")) selects[i].icon_nbr=atoi(a); 
            else {
                error = i+1;
                break; 
            }
        }
    else error = 1; 
    if (error) for(i=0; i<NBSELECTS; i++) selects[i].icon_nbr=i;
    return error;
}

char * save_icon_str(void)
{
    static char str[NBSELECTS*3+1];
    char * temp;
    int i;
    
    temp=(char *) malloc (4);
    sprintf(str, "%i", selects[0].icon_nbr);
    for(i=1; i<NBSELECTS; i++) {
        sprintf(temp, ",%i", selects[i].icon_nbr);
        strcat(str, temp); }
    free(temp);
    return(str);    
}

void setup_icon(void)
{
    int i;
    
    for(i=0; i<NBSELECTS; i++)
        if ((selects[i].icon_nbr>=0) && (selects[i].icon_nbr<NB_PANEL_ICONS))
              fl_set_pixmap_data(fd_XFCE->selects[i], 
               				icon_data[selects[i].icon_nbr]);
        else
              fl_set_pixmap_data(fd_XFCE->selects[i], icon_data[i]);
}

void default_icon_str(void)
{
    char *s;
    
    s = (char *) malloc(NBSELECTS*3+1);
    strcpy(s, "0,1,2,3,4,5,6");
    load_icon_str(s);
    setup_icon();
    free(s);
}

int get_icon_nbr(int no_cmd)
{
    return(selects[no_cmd].icon_nbr);
}

void set_icon_nbr(int no_cmd, int icon_nbr)
{
     selects[no_cmd].icon_nbr = icon_nbr;
     fl_set_pixmap_data(fd_XFCE->selects[no_cmd], icon_data[icon_nbr]);
}

void init_choice_str(FL_OBJECT * obj)
{
    int i;
    
    for(i=0; i<NB_PANEL_ICONS; i++) 
        fl_addto_choice(obj, icon_name[i]);
}

void set_choice_value(FL_OBJECT * obj, int no_cmd)
{
    fl_set_choice(obj, selects[no_cmd].icon_nbr + 1);
}
