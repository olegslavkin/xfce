/*
   XPM 
 */
static char *file1[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48       12            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #ffffff",
  "a c #ff00ff",
  "b c #aaa2a2",
  "c c #615959",
  "d c #ff0000",
  "e c #00ff00",
  "f c #0000ff",
  "g c #fff7f7",
  "h c #183c59",
  "i c #ffff00",
/*
   pixels 
 */
  "+++++++++++++++++++++++++++###++++++++++++++++++",
  "+++++++++++++++++++++++++##aaa##++++++++++++++++",
  "+++++++++++++++++++++++##aaaaa###b++++++++++++++",
  "+++++++++++++++++++++##aaaaa###...b+++++++++++++",
  "+++++++++++++++++++++#aaaa###.....b+++++++++++++",
  "+++++++++++++++++++++#aa###........b++++++++++++",
  "++ccccccccccccccccccc####..........bccc+++++++++",
  "++cccccccccccccccccc###.............bcc+++++++++",
  "++cccccccccccccccc###...............bcc+++++++++",
  "++cccccccccccccc###..................bc+++++++++",
  "++cbccc#######################b......bc+++++++++",
  "++cbbc#ddddddd#eeeeeee#fffffff#b......b+++++++++",
  "++cbb#ddddddd#eeeeeee#fffffffff#b.....b+++++++++",
  "++cbbggggggggggggggggggggggggggggggggggggg++++++",
  "++cbbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbh++++++",
  "++cbbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbh++++++",
  "++ccbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbh++++++",
  "++cccgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbh++++++",
  "++cccgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbh++++++",
  "++cccgbbbbbbbbbb###############bbbbbbbbbbh++++++",
  "++cccgbbbbbbbbbb#bbbbbbbbbbbbb#cbbbbbbbbbhb+++++",
  "++cbcgbbbbbbbbbb#biiiiiiiiiiii#cbbbbbbbbbhbb++++",
  "++cbbgbbbbbbbbbb#biiiiiiiiiiii#cbbbbbbbbbhbbb+++",
  "++cbbgbbbbbbbbbb#biiiiiiiiiiii#cbbbbbbbbbhcbbb++",
  "++cbbgbbbbbbbbbb#hhhhhhhhhhhhh#cbbbbbbbbbhccbbb+",
  "++cbbgbbbbbbbbbb#hcccccccccccc#cbbbbbbbbbhcccbb+",
  "++cbbgbbbbbbbbbb#hbbbbbbbbbbbb#cbbbbbbbbbhcccbb+",
  "++ccbgbbbbbbbbbb###############cbbbbbbbbbhcccbb+",
  "++cccgbbbbbbbbbbbcccccccccccccccbbbbbbbbbhcccbb+",
  "++cccgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cccgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cccgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cbcgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cbbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cbbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cbbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++cbbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "+++bbgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "++++bgbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "+++++gbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "+++++gbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "+++++gbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbhcccbb+",
  "+++++ghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhcccbb+",
  "+++++++++bbbcccccccccccccccccccccccccccccccccbb+",
  "++++++++++bbbccccccccccccccccccccccccccccccccbb+",
  "+++++++++++bbbcccccccccccccccccccccccccccccccbb+",
  "++++++++++++bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb+",
  "+++++++++++++bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb+"};
