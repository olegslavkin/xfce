/*
   XPM 
 */
static char *man[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        8            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #c6bebe",
  "# c #615959",
  "a c #183c59",
  "b c #aaa2a2",
  "c c #817979",
  "d c #fff7f7",
  "e c #ffffff",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++##########++++++++++++++++++++",
  "++++++++++########abcccccc#a++++++++++++++++++++",
  "++++++++++#cd.bbcaabcccccc#a++++++++++++++++++++",
  "++++++++++#cd.bbcaabcccccc#a+++++##########+++++",
  "++++++++++##d.bbcaabcccccc#a+++++#dd..bbbca+++++",
  "++++######a#d.bbcaabcccccc#a#####add..bbbcab++++",
  "++++#ddd+ba#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#dbc#caabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aaddbbcc#ca#b+++",
  "++++#dbc#ca#dbc#caabeeeeeeaaabc#aaddbbcc#ca#b+++",
  "++++#dbc#cacd.bbcaaeeeeeeeeaabc#aadd..bbbca#b+++",
  "++++#d.bbcacdbc#caeeeeeeeeeeabc#aaddbbcc#ca#b+++",
  "++++#dbc#cacd.bbceeeeaaa#eeeebc#aadd..bbbca#b+++",
  "++++#dbc#ca#d.bbceeeaaccc#eeebc#aadd..bbbca#b+++",
  "++++#d+bbca#d.bbceeeacccc#eeebc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbceeeacccc#eeebc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaaacccc#eeeebc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabccc#eeeeabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcc#eeeeaabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabc#eeeeaaabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#eeeea#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#eeeac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#eeeac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcaaaac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#eeecc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#dbc#caab#eeeac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#eeeac#aabc#aadd..bbbca#b+++",
  "++++#dbc#ca#dbc#caabcaaaac#aabc#aadd..bbbca#b+++",
  "++++#dbc#ca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#dbc#caabcccccc#aabc#aaddbbcc#ca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aaddbbcc#ca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#bbbcca#d.bbcaabcccccc#aabc#aa########a#b+++",
  "++++#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#aaaaaa#b+++",
  "++++#dddddddddddddddddddddddddddddddb#######b+++",
  "+++++++++++++++++++++++++++++++++++++bbbbbbbb+++",
  "++++++++++++++++++++++++++++++++++++++bbbbbbb+++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++"};
