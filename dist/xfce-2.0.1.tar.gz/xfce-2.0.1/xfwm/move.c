/*
 * This module is all original code 
 * by Rob Nation 
 * Copyright 1993, Robert Nation
 *     You may use this code for any purpose, as long as the original
 *     copyright remains in the source code and all documentation
 ****************************************************************************/

/***********************************************************************
 *
 * code for moving windows
 *
 ***********************************************************************/

#include "configure.h"

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <X11/keysym.h>
#include "xfwm.h"
#include "menus.h"
#include "misc.h"
#include "parse.h"
#include "screen.h"
#include "module.h"

extern XEvent Event;
extern int menuFromFrameOrWindowOrTitlebar;
Bool NeedToResizeToo;

/****************************************************************************
 *
 * Start a window move operation
 *
 ****************************************************************************/
void
move_window (XEvent * eventp, Window w, XfwmWindow * tmp_win,
	     unsigned long context, char *action, int *Module)
{
  int FinalX, FinalY;
  int val1, val2, val1_unit, val2_unit, n;

  n = GetTwoArguments (action, &val1, &val2, &val1_unit, &val2_unit);

  if (DeferExecution (eventp, &w, &tmp_win, &context, MOVE, ButtonPress))
    return;

  /* gotta have a window */
  w = tmp_win->frame;
  if (tmp_win->flags & ICONIFIED)
    {
      if (tmp_win->icon_pixmap_w != None)
	{
	  XUnmapWindow (dpy, tmp_win->icon_w);
	  w = tmp_win->icon_pixmap_w;
	}
      else
	w = tmp_win->icon_w;
    }

  if (n == 2)
    {
      FinalX = val1 * val1_unit / 100;
      FinalY = val2 * val2_unit / 100;
    }
  else
    InteractiveMove (&w, tmp_win, &FinalX, &FinalY, eventp);


  if (w == tmp_win->frame)
    {
      SetupFrame (tmp_win, FinalX, FinalY,
		  tmp_win->frame_width, tmp_win->frame_height, FALSE);
    }
  else
    /* icon window */
    {
      tmp_win->flags |= ICON_MOVED;
      tmp_win->icon_x_loc = FinalX;
      tmp_win->icon_xl_loc = FinalX -
	(tmp_win->icon_w_width - tmp_win->icon_p_width) / 2;
      tmp_win->icon_y_loc = FinalY;
      Broadcast (M_ICON_LOCATION, 7, tmp_win->w, tmp_win->frame,
		 (unsigned long) tmp_win,
		 tmp_win->icon_x_loc, tmp_win->icon_y_loc,
		 tmp_win->icon_w_width, tmp_win->icon_w_height
		 + tmp_win->icon_p_height);
      XMoveWindow (dpy, tmp_win->icon_w,
		   tmp_win->icon_xl_loc, FinalY + tmp_win->icon_p_height);
      if (tmp_win->icon_pixmap_w != None)
	{
	  XMapWindow (dpy, tmp_win->icon_w);
	  XMoveWindow (dpy, tmp_win->icon_pixmap_w, tmp_win->icon_x_loc, FinalY);
	  XMapWindow (dpy, w);
	}

    }

  return;
}



/****************************************************************************
 *
 * Move the rubberband around, return with the new window location
 *
 ****************************************************************************/
void
moveLoop (XfwmWindow * tmp_win, int XOffset, int YOffset, int Width,
	  int Height, int *FinalX, int *FinalY, Bool opaque_move,
	  Bool AddWindow)
{
  Bool finished = False;
  Bool done;
  int xl, yt, delta_x, delta_y, paged;

  XQueryPointer (dpy, Scr.Root, &JunkRoot, &JunkChild, &xl, &yt,
		 &JunkX, &JunkY, &JunkMask);
  xl += XOffset;
  yt += YOffset;

  while (!finished)
    {
      /* block until there is an interesting event */
      XMaskEvent (dpy, ButtonPressMask | ButtonReleaseMask | KeyPressMask |
	       PointerMotionMask | ButtonMotionMask | ExposureMask, &Event);
      StashEventTime (&Event);

      /* discard any extra motion events before a logical release */
      if (Event.type == MotionNotify)
	{
	  while (XCheckMaskEvent (dpy, PointerMotionMask | ButtonMotionMask |
				  ButtonPressMask | ButtonRelease, &Event))
	    {
	      StashEventTime (&Event);
	      if (Event.type == ButtonRelease)
		break;
	    }
	}

      done = FALSE;
      /* Handle a limited number of key press events to allow mouseless
       * operation */
      if (Event.type == KeyPress)
	Keyboard_shortcuts (&Event, ButtonRelease);
      switch (Event.type)
	{
	case KeyPress:
	  /* simple code to bag out of move - CKH */
	  if (XLookupKeysym (&(Event.xkey), 0) == XK_Escape)
	    {
	      *FinalX = tmp_win->frame_x;
	      *FinalY = tmp_win->frame_y;
	      finished = TRUE;
	    }
	  done = TRUE;
	  break;
	case ButtonPress:
	  XAllowEvents (dpy, ReplayPointer, CurrentTime);
	  if ((Event.xbutton.button == 1) && (Event.xbutton.state & ShiftMask))
	    {
	      NeedToResizeToo = True;
	      /* Fallthrough to button-release */
	    }
	  else
	    {
	      done = 1;
	      break;
	    }
	case ButtonRelease:
	  xl = Event.xmotion.x_root + XOffset;
	  yt = Event.xmotion.y_root + YOffset;

	  /* Resist moving windows over the edge of the screen! */
	  if (((xl + Width) >= Scr.MyDisplayWidth) &&
	      ((xl + Width) < Scr.MyDisplayWidth + Scr.MoveResistance))
	    xl = Scr.MyDisplayWidth - Width - tmp_win->bw;
	  if ((xl <= 0) && (xl > -Scr.MoveResistance))
	    xl = 0;
	  if (((yt + Height) >= Scr.MyDisplayHeight) &&
	      ((yt + Height) < Scr.MyDisplayHeight + Scr.MoveResistance))
	    yt = Scr.MyDisplayHeight - Height - tmp_win->bw;
	  if ((yt <= 0) && (yt > -Scr.MoveResistance))
	    yt = 0;

	  *FinalX = xl;
	  *FinalY = yt;

	  done = TRUE;
	  finished = TRUE;
	  break;

	case MotionNotify:
	  xl = Event.xmotion.x_root;
	  yt = Event.xmotion.y_root;
	  /* redraw the rubberband */
	  xl += XOffset;
	  yt += YOffset;

	  /* Resist moving windows over the edge of the screen! */
	  if (((xl + Width) >= Scr.MyDisplayWidth) &&
	      ((xl + Width) < Scr.MyDisplayWidth + Scr.MoveResistance))
	    xl = Scr.MyDisplayWidth - Width - tmp_win->bw;
	  if ((xl <= 0) && (xl > -Scr.MoveResistance))
	    xl = 0;
	  if (((yt + Height) >= Scr.MyDisplayHeight) &&
	      ((yt + Height) < Scr.MyDisplayHeight + Scr.MoveResistance))
	    yt = Scr.MyDisplayHeight - Height - tmp_win->bw;
	  if ((yt <= 0) && (yt > -Scr.MoveResistance))
	    yt = 0;

	  /* check Paging request once and only once after outline redrawn */
	  /* redraw after paging if needed - mab */
	  paged = 0;
	  while (paged <= 1)
	    {
	      if (tmp_win->flags & ICONIFIED)
		{
		  tmp_win->icon_x_loc = xl;
		  tmp_win->icon_xl_loc = xl -
		    (tmp_win->icon_w_width - tmp_win->icon_p_width) / 2;
		  tmp_win->icon_y_loc = yt;
		  if (tmp_win->icon_pixmap_w != None)
		    XMoveWindow (dpy, tmp_win->icon_pixmap_w,
				 tmp_win->icon_x_loc, yt);
		  else if (tmp_win->icon_w != None)
		    XMoveWindow (dpy, tmp_win->icon_w, tmp_win->icon_xl_loc,
				 yt + tmp_win->icon_p_height);

		}
	      else
		XMoveWindow (dpy, tmp_win->frame, xl, yt);
	      if (paged == 0)
		{
		  xl = Event.xmotion.x_root;
		  yt = Event.xmotion.y_root;
		  HandlePaging (Scr.EdgeScrollX, Scr.EdgeScrollY, &xl, &yt,
				&delta_x, &delta_y, False);
		  xl += XOffset;
		  yt += YOffset;
		  if ((delta_x == 0) && (delta_y == 0))
		    break;	/* break from while paged */
		}
	      paged++;
	    }			/* end while paged */

	  done = TRUE;
	  break;

	default:
	  break;
	}
      if (!done)
	{
	  DispatchEvent ();
	}
    }
}

/****************************************************************************
 *
 * For menus, move, and resize operations, we can effect keyboard 
 * shortcuts by warping the pointer.
 *
 ****************************************************************************/
void
Keyboard_shortcuts (XEvent * Event, int ReturnEvent)
{
  int x, y, x_root, y_root;
  int move_size, x_move, y_move;
  KeySym keysym;

  /* Pick the size of the cursor movement */
  move_size = Scr.EntryHeight;
  if (Event->xkey.state & ControlMask)
    move_size = 1;
  if (Event->xkey.state & ShiftMask)
    move_size = 100;

  keysym = XLookupKeysym (&Event->xkey, 0);

  x_move = 0;
  y_move = 0;
  switch (keysym)
    {
    case XK_Up:
    case XK_k:
    case XK_p:
      y_move = -move_size;
      break;
    case XK_Down:
    case XK_n:
    case XK_j:
      y_move = move_size;
      break;
    case XK_Left:
    case XK_b:
    case XK_h:
      x_move = -move_size;
      break;
    case XK_Right:
    case XK_f:
    case XK_l:
      x_move = move_size;
      break;
    case XK_Return:
    case XK_space:
      /* beat up the event */
      Event->type = ReturnEvent;
      break;
    case XK_Escape:
      /* simple code to bag out of move - CKH */
      /* return keypress event instead */
      Event->type = KeyPress;
      Event->xkey.keycode = XKeysymToKeycode (Event->xkey.display, keysym);
      break;
    default:
      break;
    }
  XQueryPointer (dpy, Scr.Root, &JunkRoot, &Event->xany.window,
		 &x_root, &y_root, &x, &y, &JunkMask);

  if ((x_move != 0) || (y_move != 0))
    {
      /* beat up the event */
      XWarpPointer (dpy, None, Scr.Root, 0, 0, 0, 0, x_root + x_move,
		    y_root + y_move);

      /* beat up the event */
      Event->type = MotionNotify;
      Event->xkey.x += x_move;
      Event->xkey.y += y_move;
      Event->xkey.x_root += x_move;
      Event->xkey.y_root += y_move;
    }
}


void
InteractiveMove (Window * win, XfwmWindow * tmp_win, int *FinalX, int *FinalY, XEvent * eventp)
{
  extern int Stashed_X, Stashed_Y;
  int origDragX, origDragY, DragX, DragY, DragWidth, DragHeight;
  int XOffset, YOffset;
  Window w;

  Bool opaque_move = True;

  w = *win;

  InstallRootColormap ();
  if (menuFromFrameOrWindowOrTitlebar)
    {
      /* warp the pointer to the cursor position from before menu appeared */
      XWarpPointer (dpy, None, Scr.Root, 0, 0, 0, 0, Stashed_X, Stashed_Y);
      XFlush (dpy);
    }


  DragX = eventp->xbutton.x_root;
  DragY = eventp->xbutton.y_root;

  if (!GrabEm (MOVE))
    {
      XBell (dpy, Scr.screen);
      return;
    }

  XGetGeometry (dpy, w, &JunkRoot, &origDragX, &origDragY,
		(unsigned int *) &DragWidth, (unsigned int *) &DragHeight,
		&JunkBW, &JunkDepth);

  DragWidth += JunkBW;
  DragHeight += JunkBW;
  XOffset = origDragX - DragX;
  YOffset = origDragY - DragY;
  moveLoop (tmp_win, XOffset, YOffset, DragWidth, DragHeight, FinalX, FinalY,
	    opaque_move, False);
  UninstallRootColormap ();

  UngrabEm ();

}
