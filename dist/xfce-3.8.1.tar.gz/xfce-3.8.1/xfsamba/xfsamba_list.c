/* (c) 2001 Edscott Wilson Garcia GNU/GPL
* this file is included by xfsamba.c
* (touch xfsamba.c if modified)
* please see xfsamba.c for copyright notice */

/* functions to use tubo.c for listing contents of SMB shares */

/******* SMBlist (was SMDclient) */



/* function to process stdout produced by child */
static int
SMBListStdout (int n, void *data)
{
  char *line;
  char *textos[3];
  char directorio[XFSAMBA_MAX_STRING];
  if (n)
    return TRUE;		/* this would mean binary data */
  line = (char *) data;
  print_diagnostics (line);
  if (strstr (line, "ERRbadpw"))
    {				/* server has died */
      SMBResult = CHALLENGED;
      print_diagnostics ("DBG:");
      print_diagnostics (line);
/* here we must pop it from the cache!!!!! */
    }
  if (strlen (line) < 2)
    return TRUE;
  if (strstr (line, "  .   "))
    return TRUE;
  if (strstr (line, "  ..   "))
    return TRUE;
  if (strncmp (line, "  ", 2))
    return TRUE;
  /* ok. Now we have a line to process */
  /* client.c: "  %-30s%7.7s %8.0f  %s",filename,attr,size,asctime */
  /* asctime=25 */
 // if (strlen(line) > 25+2+8+1+7)
  {
    int i, filenamelen, caso = 0x01;
    char *pw;
    GdkPixmap *gPIX;
    GdkBitmap *gPIM;
    
pw = line + (strlen (line) -1 - 25 - 2 - 8);
while (pw[0]!=' ') {
	if (pw==line) break;
	pw--;
}

    filenamelen = strlen (line) - strlen(pw) - 7;

while (pw[0]==' '){
	if (pw[0]==0) break;
	pw++;
}

    
    /*filenamelen = strlen (line) - 25 - 2 - 8 - 1 - 7;*/
    textos[0] = "";
    textos[1] = line + 2;
    for (i = filenamelen + 1; i < filenamelen + 8; i++)
      {
	if (line[i] == 'D')
	  caso ^= 0x08;
	if (line[i] == 'H')
	  caso ^= 0x04;
	if (line[i] == 'R')
	  caso ^= 0x02;
	line[i] = 0;
      }
    textos[2] = pw;

    latin_1_readable (line);
    if (strstr (textos[2], "\n"))
      strtok (textos[2], "\n");	/* chop */

    if (caso & 0x08)
      {
	if (strcmp (selected.dirname, "/") == 0)
	  {
	    sprintf (directorio, "/%s/%s", NMBshare, line + 2);
	  }
	else
	  {
	    sprintf (directorio, "/%s%s/%s", NMBshare, selected.dirname,
		     line + 2);
	  }
	textos[2] = directorio;
	gtk_ctree_insert_node ((GtkCTree *) shares,
			       (GtkCTreeNode *) selected.node, NULL, textos,
			       3, gPIX_dir_close, gPIM_dir_close,
			       gPIX_dir_open, gPIM_dir_open, FALSE, FALSE);
	return TRUE;
      }
    /* here, use different icons or notify readonly or hidden... */
    gPIX = gPIX_page;
    gPIM = gPIM_page;		/* default */
    if (caso & 0x02)
      {
	gPIX = gPIX_rpage;
	gPIM = gPIM_rpage;
      }				/* readonly */
    if (caso & 0x04)
      {				/* hidden */
	if (caso & 0x02)
	  {
	    gPIX = gPIX_rdotfile;
	    gPIM = gPIM_rdotfile;
	  }			/* readonly */
	else
	  {
	    gPIX = gPIX_dotfile;
	    gPIM = gPIM_dotfile;
	  }
      }				/* hidden */
    gtk_ctree_insert_node ((GtkCTree *) shares,
			   (GtkCTreeNode *) selected.node, NULL, textos, 3,
			   gPIX, gPIM, NULL, NULL, TRUE, FALSE);
  }

  return TRUE;
}

/* function to be run by parent after child has exited
*  and all data in pipe has been read : */
static void
SMBListForkOver (void)
{
  /* no jalo para arreglar directorios: 
     gtk_ctree_sort_node ((GtkCTree *)shares,(GtkCTreeNode *)selected.node);
   */
  gtk_clist_thaw (GTK_CLIST (shares));
  cursor_reset (GTK_WIDGET (smb_nav));
  animation (FALSE);
  print_status (_("Retrieve done."));
  fork_obj = 0;
  switch (SMBResult)
    {
    case CHALLENGED:
      print_status (_("Query password has been requested."));
      gtk_window_set_transient_for (GTK_WINDOW (passwd_dialog ()),
				    GTK_WINDOW (smb_nav));
      break;
    default:
      break;

    }
}

/* function executed by child after all pipes
*  timeouts and inputs have been set up */
static void
SMBListFork (void)
{
  char *the_netbios;
  the_netbios =
    (char *) malloc (strlen (NMBnetbios) + strlen (NMBshare) + 1 + 3);
  sprintf (the_netbios, "//%s/%s", NMBnetbios, NMBshare);

  fprintf (stderr, "CMD: SMBclient fork: ");
  fprintf (stderr, "smbclient %s   %s   %s   %s   %s\n", the_netbios, "-U",
	   "*******", "-c", NMBcommand);
  fflush (NULL);
  execlp ("smbclient", "smbclient", the_netbios, "-U", NMBpassword, "-c",
	  NMBcommand, (char *) 0);
}


void
SMBList (void)
{
  if (not_unique (fork_obj))
    {
      return;
    }
  /* LastNode not used in this file! anywhere else? */
  LastNode = (GtkCTreeNode *) selected.node;

  if (strlen (selected.dirname) + strlen ("ls") + 4 > XFSAMBA_MAX_STRING)
    {
      print_diagnostics ("DBG: Max string exceeded!");
      print_status (_("List failed."));
      animation (FALSE);
      cursor_reset (GTK_WIDGET (smb_nav));

      return;

    }

  sprintf (NMBcommand, "ls \\\"%s\\\"*", selected.dirname);

  strncpy (NMBnetbios, thisN->netbios, XFSAMBA_MAX_STRING);
  NMBnetbios[XFSAMBA_MAX_STRING] = 0;

  strncpy (NMBshare, selected.share, XFSAMBA_MAX_STRING);
  NMBshare[XFSAMBA_MAX_STRING] = 0;

  strncpy (NMBpassword, thisN->password, XFSAMBA_MAX_STRING);
  NMBpassword[XFSAMBA_MAX_STRING] = 0;

  print_status (_("Retreiving..."));

  gtk_clist_freeze (GTK_CLIST (shares));
  fork_obj = Tubo (SMBListFork, SMBListForkOver, TRUE,
		   SMBListStdout, parse_stderr);
  return;
}
