/* (c) 2001 Edscott Wilson Garcia GNU/GPL
* this file is included by xfsamba.c
* please see xfsamba.c for copyright notice 
* (touch xfsamba.c if modified) */

/* functions to use tubo.c for resolving master
*  browser IP address into a netbios name  */


/* function to be run by parent after child has exited
*  and all data in pipe has been read : */
static void
NMBmastersResolveOver (void)
{
  static gboolean NMBmastersResolve (nmb_list * currentN);
  char *message;
  cursor_reset (GTK_WIDGET (smb_nav));
  animation (FALSE);
  fork_obj = NULL;
  if (thisN->netbios)
    {
      int i;
      thisN->server = (char *) malloc (strlen (thisN->netbios) + 1);
      for (i = 0; i <= strlen (thisN->netbios); i++)
	{
	  strcpy (thisN->server, thisN->netbios);
	  latin_1_readable (thisN->server);
	}
      if (items != NULL)
	{
	  g_list_free (items);
	  items = NULL;
	}
      items = g_list_append (items, thisN->server);

      gtk_combo_set_popdown_strings (GTK_COMBO (location), items);
      smoke_nmb (thisN);
      reverse_smoke_nmb (thisN);
      headN = thisN;
      message =
	(char *) malloc (strlen (_("Resolved")) + strlen (thisN->netbios) +
			 5);
      sprintf (message, "%s : %s", _("Resolved"), thisN->netbios);
      print_status (message);
      free (message);
      SMBLookup (NULL, TRUE);
      return;
    }
  /* master browser not resolved  */
  if (thisN->serverIP)
    {
      message =
	(char *) malloc (strlen (_("No status response")) +
			 strlen (thisN->serverIP) + 5);
      sprintf (message, "%s : %s", _("No status response"), thisN->serverIP);
      print_status (message);
      free (message);
    }
  else
    {
      print_status (_("No status response"));
    }

  thisN = thisN->next;
  if (!thisN)
    {				/* alert no master browser found on network */
      print_status (_
		    ("Master browser not resolved. Use location box to browse."));
      clean_nmb ();
      return;
    }
  NMBmastersResolve (thisN);
}

/* function to process stdout produced by child */
static int
NMBparseMastersResolve (int n, void *data)
{
  char *line;
  if (n)
    return TRUE;		/* this would mean binary data */
  line = (char *) data;
  print_diagnostics (line);
  if (!NMBfirst)
    return TRUE;
  if (!strstr (line, "<00>"))
    return TRUE;
  NMBfirst = 0;
  strtok (line, " ");
  thisN->netbios = (char *) malloc (strlen (line) + 1);
  /* chupo faros check */
  strcpy (thisN->netbios, line + 1);
  return TRUE;
}

/* function executed by child after all pipes
*  timeouts and inputs have been set up */
static void
NMBmastersResolveFork (void)
{
#ifdef DBG_XFSAMBA
  fprintf (stderr, "DBG: nmblookup -A %s\n", NMBserverIP);
  fflush (NULL);
#endif
  execlp ("nmblookup", "nmblookup", "-A", NMBserverIP, (char *) 0);
}

static gboolean
NMBmastersResolve (nmb_list * currentN)
{
  char *message;
  if (!currentN)
    return FALSE;
  if (fork_obj)
    return FALSE;
  NMBfirst = 1;
  thisN = currentN;
  cursor_wait (GTK_WIDGET (smb_nav));
  animation (TRUE);
  message =
    (char *) malloc (strlen (currentN->serverIP) + strlen (_("Resolving")) +
		     2);
  sprintf (message, "%s %s", _("Resolving"), currentN->serverIP);
  print_status (message);
  free (message);

  strncpy (NMBserverIP, currentN->serverIP, XFSAMBA_MAX_STRING);
  NMBserverIP[XFSAMBA_MAX_STRING] = 0;

  fork_obj = Tubo (NMBmastersResolveFork, NMBmastersResolveOver, FALSE,
		   NMBparseMastersResolve, parse_stderr);
  return FALSE;
}
