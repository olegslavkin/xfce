/* (c) 2001 Edscott Wilson Garcia GNU/GPL
* this file is included by xfsamba.c
* please see xfsamba.c for copyright notice 
* (touch xfsamba.c if modified) */

/* functions to use tubo.c for uploading SMB files */

/*******SMBPut******************/
/* function to process stdout produced by child */
static int
SMBPutStdout (int n, void *data)
{
  char *line;
  if (n)
    return TRUE;		/* this would mean binary data */
  line = (char *) data;
  if (strstr (line, "ERRDOS"))
    {				/* server has died */
      SMBResult = CHALLENGED;
    }
  print_diagnostics (line);

  return TRUE;
}

/* function to be run by parent after child has exited
*  and all data in pipe has been read : */

static char *fileUp;
static void
SMBPutForkOver (void)
{
  cursor_reset (GTK_WIDGET (smb_nav));
  animation (FALSE);
  switch (SMBResult)
    {
    case CHALLENGED:
      print_status (_("File upload failed. See diagnostics for reason."));
      break;
    default:
      /* upload was successful: */
      {
	char *textos[3];
	print_status (_("Upload done."));
	textos[0] = "";
	textos[1] = fileUp;
	textos[2] = _("Uploaded file.");
	gtk_ctree_insert_node ((GtkCTree *) shares,
			       (GtkCTreeNode *) selected.node, NULL, textos,
			       3, gPIX_page, gPIM_page, NULL, NULL, TRUE,
			       FALSE);
      }
      break;

    }
  fork_obj = NULL;
}


void
SMBPutFile (void)
{
  glob_t dirlist;
  char *fileS, *dataO;
  int i;

  if (!selected.directory)
    {
      return;
    }
  if (not_unique (fork_obj))
    {
      return;
    }

  print_status (_("Uploading file..."));


  fileS = open_fileselect ("");
  if (!fileS)
    {
      print_status (_("File upload cancelled."));
      animation (FALSE);
      cursor_reset (GTK_WIDGET (smb_nav));
      return;
    }


  if (glob (fileS, GLOB_ERR, NULL, &dirlist) != 0)
    {
      globfree (&dirlist);
      my_show_message (_("Specified file does not exist"));
      print_status (_("Upload failed."));
      animation (FALSE);
      cursor_reset (GTK_WIDGET (smb_nav));
      return;
    }
  globfree (&dirlist);

  fileUp = fileS;
  while (strstr (fileUp, "/"))
    fileUp = strstr (fileUp, "/") + 1;

  if (strlen (fileUp) + strlen (selected.dirname) + strlen (fileS) +
      strlen ("put") + 5 > XFSAMBA_MAX_STRING)
    {
      print_diagnostics ("DBG: Max string exceeded!");
      print_status (_("Upload failed."));
      animation (FALSE);
      cursor_reset (GTK_WIDGET (smb_nav));
      return;

    }

  dataO = (char *) malloc (strlen (selected.dirname) + 1);

  strcpy (dataO, selected.dirname);
  for (i = 0; i < strlen (dataO); i++)
    {
      if (dataO[i] == '/')
	{
	  dataO[i] = '\\';
	}
    }


  sprintf (NMBcommand, "put \"%s\" \\\"%s\\%s\\\"", fileS, dataO, fileUp);
  free (dataO);
  print_diagnostics (NMBcommand);
  print_diagnostics ("\n");


  strncpy (NMBnetbios, thisN->netbios, XFSAMBA_MAX_STRING);
  NMBnetbios[XFSAMBA_MAX_STRING] = 0;

  strncpy (NMBshare, selected.share, XFSAMBA_MAX_STRING);
  NMBshare[XFSAMBA_MAX_STRING] = 0;

  strncpy (NMBpassword, thisN->password, XFSAMBA_MAX_STRING);
  NMBpassword[XFSAMBA_MAX_STRING] = 0;

  fork_obj = Tubo (SMBClientFork, SMBPutForkOver, TRUE,
		   SMBPutStdout, parse_stderr);
  return;
}
