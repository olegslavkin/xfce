/* (c) 2001 Edscott Wilson Garcia GNU/GPL
* this file is included by xfsamba.c
* please see xfsamba.c for copyright notice 
* (touch xfsamba.c if modified) */

/* functions to use tubo.c for master browsere lookup */

/* nmb lookup: **/

/* function to be run by parent after child has exited
*  and all data in pipe has been read : */


static void
NMBmastersForkOver (void)
{
  cursor_reset (GTK_WIDGET (smb_nav));
  animation (FALSE);
  fork_obj = NULL;
  /* print_diagnostics("DBG:Master servers on subnet:\n"); */

  if (headN)
    {
      nmb_list *currentN;
      currentN = headN;
      while (currentN)
	{
	  print_diagnostics ("Master browser at ");
	  if (currentN->serverIP)
	    print_diagnostics (currentN->serverIP);
	  else
	    print_diagnostics ("?");
	  print_diagnostics ("\n");
	  currentN = currentN->next;
	}

      if (headN->serverIP)
	{
	  /*      sleep(10); */
	  NMBmastersResolve (headN);
	}
    }
  else
    {
      print_diagnostics
	("Your subnet might be SMB free, or have a win95 master browser.\nPress reload to try again\n");
      print_status (_("No master browser found. See diagnostics."));
    }

}

/* function to process stdout produced by child */
static int
NMBmastersParseLookup (int n, void *data)
{
  char *line, *buffer;
  nmb_list *currentN;
  if (n)
    return TRUE;		/* this would mean binary data */
  line = (char *) data;
  print_diagnostics (line);	/* verbose diagnostics */
  if (!strncmp (line, "querying", strlen ("querying")))
    return TRUE;
  if (strstr (line, "name_query")
      && strstr (line, "failed") && strstr (line, "__MSBROWSE__"))
    return TRUE;

  buffer = strtok (line, " ");
  currentN = push_nmb (buffer);
  if (currentN->serverIP)
    gtk_label_set_text ((GtkLabel *) locationIP, currentN->serverIP);
  return TRUE;
}

/* function executed by child after all pipes
*  timeouts and inputs have been set up */
static void
NMBmastersFork (void)
{
#ifdef DBG_XFSAMBA
  fprintf (stderr, "DBG:%s  %s  %s\n", "nmblookup", "-M", "-");
  fflush (NULL);
#endif
  execlp ("nmblookup", "nmblookup", "-M", "-", (char *) 0);
}


static gboolean
NMBmastersLookup (gpointer data)
{
  animation (FALSE);
  cursor_reset (GTK_WIDGET (smb_nav));


  /* animation may already be set in main... */


  if (fork_obj)
    return FALSE;
  cursor_wait (GTK_WIDGET (smb_nav));
  animation (TRUE);
  print_status (_("Looking for master browsers..."));
  fork_obj = Tubo (NMBmastersFork, NMBmastersForkOver, FALSE,
		   NMBmastersParseLookup, parse_stderr);
  return FALSE;
}
