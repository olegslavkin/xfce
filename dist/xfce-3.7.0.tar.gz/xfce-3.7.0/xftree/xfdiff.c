/*    xfdiff.c   */ 

/*  xfdiff (a gtk frontend for diff+patch)
 *  Copyright (C)  Edscott Wilson Garcia under GNU GPL
 *
 *  xfdiff uses several modules from XFCE which is 
 *  Copyright (c) by Olivier Fourdan under GNU GPL
 *  http://www.xfce.org/
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

/* Description:
 * 
 * XFdiff is a module for XFtree (XFCE project by Olivier Fourdan, http://www.xfce.org)
 * This module may be run from XFtree or independently, with command line
 * options (use: xfdiff -h to get a summary).
 *
 * XFdiff does no heavy processing. All it does is allow a fast and easy access
 * to the standard utilities diff and patch. Quoting Olivier: "the goal [for XFCE] 
 * is keep most system resources for the applications, and not to consume all memory 
 * and CPU usage with the desktop environment."
 * 
 * This program will open a window with two text widgets and display two files, 
 * highlighting the differences. Buttons permit rapid navigation through the 
 * diffences of the two files. Among the options, you may toggle line numbers, 
 * change highlight color, and font, toggle verbose output and other
 * stuff.
 * 
 * XFdiff can also open patch files (created in unified format) and display in
 * the same manner the differences. Buttons and a drop-down list permit rapid 
 * navigation through every file that is modified by the patch.
 * Among the options, you can specify strip level, whether or not
 * a patch file is reversed, apply or undo a patch (and for GNUC only, create a 
 * patch file of your own).
 *
 * XFdiff uses the standard libs from XFCE, GTK+, and modules from XFtree
 * and XFclock.
 * 

 
*/
/*
TODO:
on button press (button 4 and 5) send event to scrollbar widget 

 *
 *
 * */
#define __XFDIFF__
#include "xfdiff.h"

static int rightC,leftC,good_dir;
static struct stat patch_st;

/* convenience location of dialog texts */
static char *cannot_patch,*no_good_dir;
static char *cannot_read_from,*working_patch,*working_diff;
static char *identical_files,*patch_file_error,*versus,*diff_sections;
static char *empty_file,*now_forking,*finished_fork;



static void init(void){
/* convenience location of most dialog texts (and to avoid duplication) */
	please_select_outfile=_("Please select a name for the patch file in the next dialog.");
	please_select=_("Please select it in the next dialog.");
	no_patch=_("No patch file has been selected.");
	no_patch_dir=_("No directory to apply patch has been selected.");
	cannot_patch=_("Patch file can not be opened for read!");
	no_left_file=_("No left file has been selected.");	
	no_right_file=_("No right file has been selected.");	
	no_left_path=_("No left path has been selected.");	
	no_right_path=_("No right path has been selected.");	
	cannot_read_from=_("Warning: cannot read from ");
	identical_files=_("Files are identical\n(or binary files that may or may not differ)");
	patch_file_error=_("Patch file is not in unified format");
	versus=_(" versus ");
	diff_sections=_("different sections found");
	empty_file=_("****Empty file****\n");
	now_forking=_("Now forking to diff. Please be patient.\n");
	finished_fork=_("Finished forking.\n");
	working_diff=_("Working diff...\n");
	working_patch=_("Working patch...\n");
	no_good_dir=_("No file was found for patching\nEither the directory to apply patch is not correctly selected\nor an incorrect strip level was used (default -p0)\n");
/* initial sizes for text files, sizes in line numbers and average char length */
	sizeR=30,sizeL=30,sizeH=30;
	head=NULL,current=NULL;
	headF=NULL,currentF=NULL;
	reversed=strip=0;
	style=NULL;
	xfce_style=NULL;
	the_font=NULL;
	diff = NULL;
	drawA=text_right=text_left=titleR=titleL=titleD=titleP=NULL;
	diffbox=patchbox=what_dir=patch_label_box=NULL;
	done_str=(char *)malloc(128);
	if (!done_str) xfdiff_abort(E_MALLOC);
	drawP=NULL; 
	adj=NULL;
	lineW=lineH=rightC=leftC=0;
	drawGC=NULL;
	fileO=fileRR=fileI=patchO=NULL;
	fileR=fileL=fileP=fileD=NULL;
	/* not initialized: colorfg,colorbg; */
	fuente=DEFAULTFONT;
	silent=0;
	patching=0;
	applying_patch=0;
}

/* memcpy is necesary because patch file may contain binary data */
#ifdef __GNUC__
/* memcpy is a GNU extension.*/
#define MEMCPY memcpy
#else
/* memcpy is a GNU extension.*/
static void *MEMCPY(void *dest, const void *src, size_t n){
	char *destC,*srcC;
	size_t i;
	
	destC=(char *)dest;
	srcC=(char *)src;
	for (i=0;i<n;i++) destC[i]=srcC[i];
	return dest;
}
#endif

static patched_file *pushF(char *file,int offset,int length){
	if (!currentF) {
		headF = (patched_file *)malloc(sizeof(patched_file));
		if (!headF) xfdiff_abort(E_MALLOC);
		currentF = headF;
		currentF->previous = NULL;
	} else {
		currentF->next = (patched_file *)malloc(sizeof(patched_file));
		if (!currentF->next) xfdiff_abort(E_MALLOC);
		(currentF->next)->previous = currentF;
		currentF = currentF->next;
		
	}
	currentF->next = NULL;
	currentF->offset = offset;
	currentF->length = length;
	currentF->diffC = 0;
	
	currentF->file = (char *)malloc(strlen(file)+1);
	currentF->newfile = NULL;
	if (!currentF->file) xfdiff_abort(E_MALLOC);		
	strcpy(currentF->file,file);
	return currentF;
}
void cleanF(void){
	patched_file *thisF;
	if (!headF) return;
	while (headF != NULL){
		thisF = headF;
		headF = thisF->next;
		if (thisF->file) free(thisF->file);
		if (thisF->newfile) free(thisF->newfile);
		free(thisF);
	}
	headF=currentF=NULL;
	return;
}

static polygon *pushP(int topR,int botR,int topL,int botL){
	int O=3;
	if (!current) {
		head = (polygon *)malloc(sizeof(polygon));
		if (!head) xfdiff_abort(E_MALLOC);		
		current = head;
		current->previous = NULL;
	} else {
		current->next = (polygon *)malloc(sizeof(polygon));
		if (!current->next) xfdiff_abort(E_MALLOC);		
		(current->next)->previous = current;
		current = current->next;
	}
	current->next = NULL;
	current->topR = topR*lineH+O;
	current->botR = botR*lineH+O;
	current->topL = topL*lineH+O;
	current->botL = botL*lineH+O;
	
	current->topLR = topR+1;
	current->botLR = botR+1;
	current->topLL = topL+1;
	current->botLL = botL+1;
	return current;
}
void cleanP(void){
	polygon *thisP;
	if (!head) return;
	while (head != NULL){
		thisP = head;
		head = thisP->next;
		free(thisP);
	}
	head=current=NULL;
	return;
}


void cleanA(void){
	GdkRectangle update_rect;
	int height;
	if (rightC) height = (rightC+1) * lineH;
	else height = drawA->allocation.height;

	update_rect.x =	0;
	update_rect.y = GTK_ADJUSTMENT (adj)->value;
	update_rect.width = drawA->allocation.width;
	update_rect.height = drawA->allocation.height;

	gdk_draw_rectangle (drawP,drawA->style->bg_gc[GTK_WIDGET_STATE (drawA)],
	                   TRUE,0, 0,
	                   drawA->allocation.width,height);
	gtk_widget_draw (drawA, &update_rect);
}

void cleanT(void){
	gtk_text_backward_delete (GTK_TEXT(text_left), 
		          gtk_text_get_length (GTK_TEXT(text_left) ) );	
	gtk_text_backward_delete (GTK_TEXT(text_right), 
		          gtk_text_get_length (GTK_TEXT(text_right) ) );	
}

static int checkfile(char *file){
	FILE *check;
	if (!file) return FALSE;
	check=fopen(file,"r");
	if (check) {fclose(check); return TRUE;}
	else {
		char *message;
		message = (char *)malloc(strlen(cannot_read_from) + strlen(file) + 1);
		if (!message) xfdiff_abort(E_MALLOC);		
		strcpy(message,cannot_read_from); 
		strcat(message,file);
		dlg_warn (message);
		free(message);
		/*fprintf(stdout,"Warning: cannot read from %s\n",(file)?file:"no file specified");*/
		return FALSE;
	}
}

static char *strip_it(char *file){
	int i;
	char *strip_file;
	if (strip) {
		strip_file=strstr(file,"/");
		if (!strip_file) {
strip_error:
			dlg_warn(_("Patch file cannot be stripped.\nPlease verify strip level"));
			return NULL;
		}
		strip_file++;
		for (i=1;i<strip;i++) {
			strip_file=strstr(strip_file,"/");
			if (!strip_file) goto strip_error;
			strip_file++;
		}
	} else strip_file=file;
	return strip_file;
}


static int pre_diff(){
	char *texto;

	if (!fileL) {
		texto=(char *)malloc(strlen(no_left_file)+strlen(please_select)+2);
		if (!texto) xfdiff_abort(E_MALLOC);		
		sprintf(texto,"%s\n%s",no_left_file,please_select);
		dlg_inf(texto);
		cb_get_fileL(NULL,NULL);
		if (!fileL) {
			sprintf(texto,"%s",no_left_file);
			dlg_warn(texto);
			free(texto);		
			return FALSE;
		}
		free(texto);
	}
	
	if (!fileR) {
		texto=(char *)malloc(strlen(no_right_file)+strlen(please_select)+2);
		if (!texto) xfdiff_abort(E_MALLOC);		
		sprintf(texto,"%s\n%s",no_right_file,please_select);
				dlg_inf(texto);
		cb_get_fileR(NULL,NULL);
		if (!fileR) {
			sprintf(texto,"%s",no_right_file);
			dlg_warn(texto);
			free(texto);
			return FALSE;
		}
		free(texto);
	}
	
	if (!checkfile(fileL)) return FALSE;
	if (!checkfile(fileR)) return FALSE;
	
	if (!patchO) {
		cleanP(); /* clean difference polygons*/
		cleanA();cleanT(); /* clean display area.*/	
	}
	
	if (!silent) {
		if (currentF) show_diag(currentF->file);
		else show_diag(fileL);
		show_diag(versus);
		if (currentF) show_diag(currentF->newfile);
		else show_diag(fileR);
		show_diag(":\n");
	}
	return TRUE;
}

static void post_diff(int diffC){
	if (patchO) return;
	if (!silent){
		if (diffC) {
			char *texto; 	/* 10 is size of MAXINT of 32 bits: */
			texto =  (char *)malloc(strlen(diff_sections)+12);
			if (!texto) xfdiff_abort(E_MALLOC);		
	       		/* 10 is size of MAXINT of 32 bits */
			sprintf(texto,"%d %s",diffC,diff_sections);
			show_diag(texto);
			free (texto);
		}
		else show_diag(identical_files);
		show_diag("\n******************************\n");
	}
}

static void pad_txt(int local_leftC,int local_rightC){
	int i;
	if (local_rightC > local_leftC) for (i=local_leftC;i<local_rightC;i++) {
		leftC++;
		gtk_text_insert (GTK_TEXT (text_left), 
		                 style->font,NULL,NULL,
		                 "\n", strlen("\n")); 
	} else for (i=local_rightC;i<local_leftC;i++){
		rightC++;
		gtk_text_insert (GTK_TEXT (text_right),
		                 style->font,NULL,NULL,
		                 "\n",strlen("\n"));
	}
}

int do_diff(void){
	static int pfd[2];
	int diffC=0;
	char pidT[32];
	
	static char *directive;
	
	sprintf(pidT,"%d", (int) getpid());
	if (!directive) directive=(char *)malloc(strlen("__xfdiff_directive__")+strlen(pidT)+1);
	sprintf(directive,"__xfdiff_directive__%s",pidT);
	
	if (!pre_diff()) return FALSE;	
	show_diag(working_diff);
	/* open the pipe */
	if (pipe(pfd) < 0) { perror("pipe"); return FALSE; }

	sprintf(done_str,"XFDIFF DONE (pid=%d)\n", (int) getpid());
	if (fork()) {/*  parent will fork to diff  */
		int status;
		dup2(pfd[1],1); /* assign parent stdout to pipe */
		close(pfd[0]);  /* not used by parent */
		
		if (fork()==0) {/* forks again, to wait for completion */
			if (patchO) execlp(DIFF,DIFF,"-u","-a","-r","-N",fileL,fileR,(char *)0);
			else execlp(DIFF,DIFF,"-D",directive,fileL,fileR,(char *)0); 
			perror("exec"); _exit(127);/* parent never gets here (hopefully) */
		}

		/* the parent waits for diff to finish */
		/*fprintf(stderr,"waiting\n");*/
		wait(&status);
		fflush(NULL);
		fprintf(stdout,"%s",done_str);

		sleep (1); /* this sleep is to avoid a "race condition" */
		fflush(NULL); /* must flush so first child can continue */
		/*fprintf(stderr,"exiting subprocesses\n");*/
		_exit(1);
	}
	
	/* meanwhile, the first child is busy reading the pipe */
	
	gtk_text_freeze (GTK_TEXT (text_right)); 
	gtk_text_freeze (GTK_TEXT (text_left));
	{
		char *line,*lineE,*input;
		int lineL=256,linecount=0;
		int right=1,left=1,topR=0,topL=0,botR=0,botL=0;
		FILE *Opatch=NULL; /* buffered, for better performance */
	        
		if (patchO) Opatch=fopen(patchO,"w");
		/* file write has been tested previously!*/
		rightC=leftC=0;
		lineH = text_right->style->font->ascent + text_right->style->font->descent;
		input=line=(char *)malloc(lineL);
		if (!input) xfdiff_abort(E_MALLOC);				
		while (1){ 
			if (!read(pfd[0],input,1)) break;
			input[1]=0;linecount++;
			if (input[0]=='\n') {
				/*printf("?:%s:%s",done_str,line);*/
				if (strncmp(line,done_str,strlen(done_str))==0) break; 
				if (patchO) {
					/*printf("line:%s",line);*/
					fwrite(line,1,linecount,Opatch);
					input=line;
					linecount=0;
					continue;
				}
				/* process precompiler directives */
				if ( (strncmp(line,"#ifdef",strlen("#ifdef"))==0) 
						&& (strstr(line,directive)) ){ /* short circuit: it's a string */
					topR=rightC;topL=leftC;
					right=1;left=0;input=line; 
					diffC++;
					/*printf("%s ifcount=%d iflevel=%d\n",lineW,ifcount,iflevel);*/
					continue;
				}
				if ( (strncmp(line,"#ifndef",strlen("#ifndef"))==0) 
						&& (strstr(line,directive)) ){
					topR=rightC;topL=leftC;
					right=0;left=1;input=line; 
					diffC++;
					continue;
				}
				if ( (strncmp(line,"#else",strlen("#else"))==0) 
						&& (strstr(line,directive)) ){
					if (right) {
						topL=leftC;
						right=0;left=1;input=line; 
						continue;
					}
					else {
						topR=rightC;
						right=1;left=0;input=line; 
						continue;
					}
				}
				if ( (strncmp(line,"#endif",strlen("#endif"))==0) 
						&& (strstr(line,directive)) ){
					
					botR=rightC;botL=leftC;
					right=left=1;input=line;
					current=pushP(topR,botR,topL,botL);
					/*printf("left=%d,%d  right=%d,%d\n",topL,botL,topR,botR);*/	
					continue;
				}
				/* write to apropriate text widget */
				if (right){
					rightC++;
					gtk_text_insert (GTK_TEXT (text_right), 
				                         style->font, 
					                 (left)?NULL:&colorfg,
				                         (left)?NULL:&colorbg, 
				                         line,linecount); 
				}
				if (left) {
					leftC++;
					gtk_text_insert (GTK_TEXT (text_left), 
				                        style->font, 
				                        (right)?NULL:&colorfg,
				                        (right)?NULL:&colorbg, 
				                        line,linecount); 
				}
				input=line;
				linecount=0;
				continue;
			}
			input++;
			if (linecount >= lineL-2) {
				/*printf("reconfiguring because line size %d exceeded\n",lineL);*/
				/* unlikely to have rice on chessboard here */
				lineE=line;
				line=(char *)malloc(lineL*2);
				if (!line) xfdiff_abort(E_MALLOC);		
				MEMCPY(line,lineE,linecount);
				free(lineE);
				input=line+linecount;
				lineL *= 2;
			}
		}
		if (patchO) fclose(Opatch);
		else {
			if (leftC != rightC) pad_txt(leftC,rightC);
		}
		free(line);	
	}
	close (pfd[0]); close (pfd[1]); /* close pipes */
	/*printf("pipes closed\n");*/
	post_diff(diffC);

	/* reset to first difference and draw polygons */
        gtk_text_thaw (GTK_TEXT (text_right));gtk_text_thaw (GTK_TEXT (text_left));
	
	if (!patchO) {
		if (!first_diff()) dlg_warn(identical_files);
		if (!patching) update_titlesD();
	}
	return TRUE;
	
}
void xfdiff_abort(int why){
	switch (why) {
		case E_SEGV:
			dlg_warn(_("A bug?\nPlease send full traceback to xfce-dev@moongroup.com"));
			break;
		case E_CLEANUP:
			break;
		case E_MALLOC:
			dlg_warn(_("Low memory (malloc) error: xfdiff_aborting run"));
			break;
		case E_FILE:
			dlg_warn(_("file open error: xfdiff_aborting run"));
			break;
		default:
			dlg_warn(_("unspecified error: xfdiff_aborting run"));
			break;
	}
	/* clean up: */
#ifdef AUTOSAVE
	cb_save_defaults(NULL,NULL);
#endif
	
	if (fileRR) remove(fileRR);
	if (fileO) remove(fileO);
	if (fileI) remove(fileI);
	gtk_main_quit();
	exit(1); /* should not get here */
}

/* find at least one file to patch */
static int check_patch_dir(void){
	patched_file *thisF;
	int fileH;
	static char *file=NULL;
	char *strip_file;
	
	good_dir=0;
	thisF=headF;
	while(thisF) {
		strip_file=strip_it(thisF->file);
		if (!strip_file) break;
	       	if (file) free(file);
		file=(char *)malloc(strlen(fileD)+strlen(strip_file)+2);
		if (!fileD) xfdiff_abort(E_MALLOC);
		sprintf(file,"%s/%s",fileD,strip_file);
		fileH=open(file,O_RDONLY);
		if (fileH != -1) {
			close(fileH);
			good_dir=1;
			break;
		}
		thisF=thisF->next;
	}
	if (good_dir) return TRUE;
	
	dlg_warn(no_good_dir);
	show_diag(no_good_dir);
	return FALSE;
	
}


static int build_tmpL(char *infile){
	int fileH,fileHI;
	static char *file;

	if (!infile) return FALSE;

	if (file) free(file);
	file=(char *)malloc(strlen(fileD)+strlen(infile)+2);
	if (!file) xfdiff_abort(E_MALLOC);
	sprintf(file,"%s/%s",fileD,infile);
	
	fileHI=creat(fileI,S_IRUSR|S_IWUSR);
	if (fileHI == -1) xfdiff_abort(E_FILE);
		
	fileH=open(file,O_RDONLY);

/*     printf("preparing %s as %s\n",file,fileI);*/
		
	if (fileH == -1) {/* a new file! */
		write(fileHI,(void *)empty_file,strlen(empty_file));
	}
	else {
		ssize_t blok_s;
		void *blok;
		blok = malloc(BLOK_SIZE);
		if (!blok) xfdiff_abort(E_MALLOC);
		while ((blok_s=read(fileH,blok,BLOK_SIZE)) > 0){
			write(fileHI,blok,blok_s);
		}
		free(blok);
	}
	close(fileH);
	close(fileHI);
	return TRUE;
}
	


/* max arguments to patch: !
 arg0 -d dir -o outfile -D directive -pNUM [-N | -R] (0)*/
#define MAX_PATCH_ARG 15

int process_patch(patched_file *thisF){
	static int pfd[2];
	static int pfd2[2];
	char *argument[MAX_PATCH_ARG];
	int fileH,arglist=0;
	char *tmp_dir=NULL;
	char strip_level[16];
	char pidT[32];
	char *file;

	if (!thisF) return FALSE;
	if (!thisF->file) return FALSE;
	if (!fileD) return FALSE; /* insurance */
	/* check for changes in patchfile */
	{
		struct stat st;
		lstat(fileP,&st);
		if ( (st.st_mtime != patch_st.st_mtime) ||
				 (st.st_ctime != patch_st.st_ctime) ){
			dlg_warn(_("Patch file has been modified by another process\nPlease reload\n"));
			cleanF();cleanT();cleanP();cleanA();
			free(fileP); fileP=NULL;
			return FALSE;
		}
	}
	
	if (strip) sprintf(strip_level,"-p%d",strip);
	else sprintf(strip_level,"-p0");
	
/*	printf("%s: offset=%d length=%d\n",thisF->file,thisF->offset,thisF->length);*/
	
	
/* TMPDIR processing */

	if (!tmp_dir) tmp_dir = getenv("TMPDIR");  
	if (!tmp_dir) tmp_dir = getenv("TMP");  
	if (!tmp_dir) tmp_dir = getenv("TEMP");  
	if (!tmp_dir) tmp_dir = TMP_DIR;

	sprintf(done_str,"XFDIFF_PATCH DONE (pid=%d)\n", (int) getpid());

	sprintf(pidT,"%x", (int) getpid());
	if (fileO) {remove(fileO); free(fileO);}
	fileO = (char *)malloc(strlen(tmp_dir)+2+strlen("xfdiffR.")+strlen(pidT));
	if (!fileO) xfdiff_abort(E_MALLOC);
	sprintf(fileO,"%s/%s%s",tmp_dir,"xfdiffR.",pidT);
		
	if (fileI) {remove(fileI); free(fileI);}
	fileI = (char *)malloc(strlen(tmp_dir)+2+strlen("xfdiffL.")+strlen(pidT));
	if (!fileI) xfdiff_abort(E_MALLOC);
	sprintf(fileI,"%s/%s%s",tmp_dir,"xfdiffL.",pidT);
	
	if (fileRR) {remove(fileRR);free(fileRR);}
	fileRR = (char *)malloc(strlen(tmp_dir)+2+strlen("xfdiff.rej.")+strlen(pidT));
	if (!fileRR) xfdiff_abort(E_MALLOC);
	sprintf(fileRR,"%s/%s%s",tmp_dir,"xfdiff.rej.",pidT);
	
	
	argument[arglist++] = PATCH; /*0*/

	
	argument[arglist++] = "-d"; /*2*/
	argument[arglist++] = fileD; /*3*/
	if (!applying_patch) {
		argument[arglist++] = "-o"; /*4*/
		argument[arglist++] = fileO; /*5*/
	}
	argument[arglist++] = "-r"; /*6*/
	argument[arglist++] = fileRR; /*7*/ //fileRR

	/* moving from -u to -D format is buggy in GNU patch! */
	
#ifdef GNU_PATCH
	if (verbose) argument[arglist++] = "--verbose"; /*8*/
#endif
	/* this should be user modify-able */
	argument[arglist++] = strip_level; /*9*/
	if (reversed) argument[arglist++] = "-R";
	else argument[arglist++] = "-N"; /*10*/ /*-N or -R */
	
       /* end of arguments */	
	argument[arglist++] = (char *) 0; /*11*/
	
	/* thisF->file address is no longer valid after forking, why? I dunno */
	file=(char *)malloc(strlen(fileD)+strlen(thisF->file)+1);
	if (!file) xfdiff_abort(E_MALLOC);
	sprintf(file,"%s",thisF->file);
	
	/* open the pipe */
	if (pipe(pfd) < 0) { perror("pipe"); return FALSE; }

 /* for the sake of clarity, dup2 commands will be placed 
  * without optimization: let -O2 take care of that */

	if (fork()) {/*  parent will fork to patch  */
		int status;
		if (pipe(pfd2) < 0) { perror("pipe2"); return FALSE; }
		if (fork()==0) {/* forks again, to wait for completion */
			dup2(pfd[1],1); /* assign parent stdout to pipe1 */
			dup2(pfd[1],2); /* assign parent stderr to pipe1 */
			close(pfd[0]);  /* not used by parent */
			close(pfd2[1]);  
			dup2(pfd2[0],0); /* assign stdin to pipe2 */
			execvp(PATCH,argument); 
			perror("exec"); _exit(127);/* parent never gets here (hopefully) */
		}
	/* send patchfile lines through pipe to patch. */
		dup2(pfd[1],1); /* assign parent stdout to pipe1 */
		close(pfd[0]);  /* not used by parent */
		close(pfd2[0]);  
		fileH=open(fileP,O_RDONLY);
		if (fileH == -1) xfdiff_abort(E_FILE); /* this should almost never be true */
applying_loop:
		lseek(fileH,thisF->offset,SEEK_SET);
		{
			void *blok;
			ssize_t blok_s;
			int readbytes;
			blok = malloc(BLOK_SIZE);
			if (!blok) xfdiff_abort(E_MALLOC);
			readbytes=thisF->length;
			while (readbytes > 0) {
				if (readbytes >= BLOK_SIZE) {
					blok_s=read(fileH,blok,BLOK_SIZE);
					
				} else {
					blok_s=read(fileH,blok,readbytes);
				}
				if (blok_s==0) break; /* hmmm */
				readbytes -= blok_s;
	
				write( pfd2[1],blok,blok_s);
				/*fwrite(blok,1,blok_s,stderr);*/
			}
			free(blok);
		}
		fflush(NULL);
		if (applying_patch){
			thisF=thisF->next;
			if (thisF) goto applying_loop;
		}
		close(pfd2[1]);
		close(fileH);
		fflush(NULL); 
		/* the parent waits for patch to finish */
		wait(&status);
		fflush(NULL);
		fprintf(stdout,"%s",done_str);
		sleep (1); /* this sleep is to avoid a "race condition" */
		fflush(NULL); /* must flush so first child can continue */
		_exit(1);
	}
	/* meanwhile, the first child is busy reading the pipe for diagnostic box
	 * after pipe has closed, the child will open create the left temporary
	 * file by means of the filelist and process it versus the right temporary file 
	 *    
	 *    Here it should be perfectly safe to use str functions in lieu of mem functions
	 *
	 *    */
	{
		char *line,*lineE,*input;
		int lineL=256;
	      
		input=line=(char *)malloc(lineL);
		if (!input) xfdiff_abort(E_MALLOC);		
		while (1){ 
			if (!read(pfd[0],input,1)) break;
			input[1]=0;
			if (input[0]=='\n') {
			        /*fprintf(stderr,"line:%s",line);*/
				if (strcmp(line,done_str)==0) break;
				/* write to apropriate text widget */
				show_diag(line);
				input=line;
				continue;
			}
			input++;
			if (strlen(line)>=lineL-2) {
				/*printf("reconfiguring because line size %d exceeded\n",lineL);*/
				/* patch output: very unlikely to have rice on chessboard */
				lineE=line;
				line=(char *)malloc(lineL*2);
				if (!line) xfdiff_abort(E_MALLOC);
				strcpy(line,lineE);
				free(lineE);
				input=line+strlen(line);
				lineL *= 2;
			}
		}
		free(line);	
	}
	close (pfd[0]); close (pfd[1]); /* close the pipe */

	/* ok, now we have to build the left temporary file */
	/*printf("before build, file:%s\n",file);*/

	if (applying_patch) return TRUE;
	
	{
		char *strip_file;
		
		strip_file=strip_it(file);
		if (!strip_file) return FALSE;
		if (!build_tmpL(strip_file)) {
			/*printf("buildtmpL failed\n");*/
			free(file);
			return FALSE;
		}
	}
	free(file);

	/* now we assign fileL and fileR and then go dodiff */
	if (fileL) free(fileL);
	fileL=(char *)malloc(strlen(fileI)+1);
	if (!fileL) xfdiff_abort(E_MALLOC);
	strcpy(fileL,fileI);

	if (fileR) free(fileR);
	fileR=(char *)malloc(strlen(fileO)+1);
	if (!fileR) xfdiff_abort(E_MALLOC);
	strcpy(fileR,fileO);

	if (good_dir) {
		show_diag(now_forking);
		do_diff();
		show_diag(finished_fork);
	}
	return TRUE;
}

static int parse_patchfile(void)
{
	char *line,*lineE,*input,*file;
	int lineL=256,linecount=0,linenumber=0;
	int offset=0,where=0;
	FILE *Pfile;
	/* use buffered i/o so single byte reads doesn't hit performance */	
	Pfile=fopen(fileP,"r"); 
	if (!Pfile) {
		dlg_warn(cannot_patch);
		return FALSE;
	}
	
	cleanF(); /* clean file list */
	lstat(fileP,&patch_st);
		
	/*printf("parsing %s\n",fileP);	*/

	input=line=(char *)malloc(lineL);
	if (!input) xfdiff_abort(E_MALLOC);
	while (!feof(Pfile)){ 
		fread(input,1,1,Pfile);	if (feof(Pfile)) break;
		where++;linecount++;
		input[1]=0;
		if (input[0]=='\n') {
			linenumber++;
			 /* this may or may not be in patch file! */
			/* if (strncmp(line,"diff",4)==0) { }*/
norice:
			if (strncmp(line,"---",3)==0) { 
				if (currentF) { /* not the first file */
				/*	currentF->length = (where - strlen(line)) - currentF->offset ;*/
					currentF->length = (where - linecount) - currentF->offset ;
				}
				 /* currentF will be pushed with filename */
				offset = where - linecount; /* before we screw up line with strtok */
				strtok(line," ");
				file=strtok(NULL,"\t");
				currentF=pushF(file,offset,0);
				/*printf("%s: offset=%d, length=%d\n",
					           currentF->file,offset,length);*/
				
			}
			if (strncmp(line,"+++",3)==0) {
				if (!currentF) {
					dlg_warn(patch_file_error);
				} else {
					strtok(line," ");
					file=strtok(NULL,"\t");
					currentF->newfile=(char *)malloc(strlen(file)+1);
					strcpy(currentF->newfile,file);
				}
			}
			input=line;
			linecount=0;
			continue;
		}
		input++;
		if (linecount >= lineL-2) {
			/*printf("%s(@%d):reconfiguring because line size %d exceeded\n",
					currentF->file,linenumber,lineL);*/
			/* Here the rice may become exponential. Must sweep */
			if (linecount >= 32768-2) goto norice;
			lineE=line;
			line=(char *)malloc(lineL*2);
			if (!line) xfdiff_abort(E_MALLOC);		
			
			MEMCPY(line,lineE,linecount);
			free(lineE);
			
			input=line+linecount;
			lineL *= 2;
		}
	}
	/* cleanup: */
	if (currentF) {
		currentF->length = where - currentF->offset;
		free(line);
		fclose(Pfile);	
	} else {
		dlg_warn(patch_file_error);
		free(line);
		fclose(Pfile);
		return FALSE;
	}
	if (!check_patch_dir()){
		/*cleanF(); process patch anyway */
	}
	return TRUE;
}

int do_patch(void) {
	int fileH;
	char *texto=NULL;


	cleanP();cleanA();cleanT(); /* clean display area.*/	
	
	if (!fileP) {
		texto=(char *)malloc(strlen(no_patch)+strlen(please_select)+2);
		if (!texto) xfdiff_abort(E_MALLOC);		
		sprintf(texto,"%s\n%s",no_patch,please_select);
		dlg_inf(texto);
		cb_get_fileP(NULL,NULL);
		if (!fileP) {
			sprintf(texto,"%s",no_patch);
			dlg_warn(texto);
			free(texto);
			return FALSE;
		}
		free(texto);
	}

	if (!fileD) {
		texto=(char *)malloc(strlen(no_patch_dir)+strlen(please_select)+2);
		if (!texto) xfdiff_abort(E_MALLOC);		
		sprintf(texto,"%s\n%s",no_patch_dir,please_select);
		dlg_inf(texto);
		cb_get_fileD(NULL,NULL);
		if (!fileD) {
			sprintf(texto,"%s",no_patch_dir);
			dlg_warn(texto);
			return FALSE;
			free(texto);
		}
		free(texto);
	}
	
	fileH=open(fileP,O_RDONLY);
	if (fileH == -1) {
		texto=(char *)malloc(strlen(cannot_patch)+1);
		if (!texto) xfdiff_abort(E_MALLOC);		
		sprintf(texto,"%s",cannot_patch);
		dlg_inf(texto);
		free(texto);
		return FALSE;
	} else close(fileH);
	
	show_diag(working_patch);


/* first, let's parse the patch file. */
	if (!parse_patchfile()) return FALSE;
	currentF=headF;
	fileH=process_patch(currentF);
	update_titlesP();
	return fileH;
}

void finish(int sig){
	if (sig==SIGSEGV) xfdiff_abort(E_SEGV);
	xfdiff_abort(E_CLEANUP);
}

int main (int argc, char *argv[])
{
	int leftA=1,rightA=2;
	int prompt=0;
	init();
	if (argc >= 2) {
		if (strcmp(argv[1],"-p")==0) {
			leftA++;rightA++;
			patching=1;prompt=0;
		}
		if ((strcmp(argv[1],"-n")==0) || 
				(strcmp(argv[1],"--no-prompt")==0)) {
			leftA++;rightA++;
			prompt=0;
		}
		if ((strcmp(argv[1],"-h")==0) || (strcmp(argv[1],"--help")==0)) {
			fprintf(stdout,"%s %s\n\n",_("xfdiff version"),XFDIFF_VERSION);
			fprintf(stdout,_("use xfdiff [ -h | --help | -p] [leftfile] [rightfile]\n"));
			fprintf(stdout,_("-p : leftfile and rightfile are a patchdir and a patchfile\n"));
			fprintf(stdout,_("-h, --help : print this message\n\n"));
			fprintf(stdout,_("xfdiff (c) Edscott Wilson Garcia 2001, under GNU-GPL\n"));
			fprintf(stdout,_("XFCE modules copyright Olivier Fourdan 1999-2001, under GNU-GPL\n\n"));
			exit(1);
		}

	}
	
	if (argc >= leftA+1 ) {
		if (patching) {
			fileD = (char *)malloc(strlen(argv[leftA])+1);
			if (!fileD) xfdiff_abort(E_MALLOC);		
			strcpy(fileD,argv[leftA]);
		} else {
			fileL = (char *)malloc(strlen(argv[leftA])+1);
			if (!fileL) xfdiff_abort(E_MALLOC);		
			strcpy(fileL,argv[leftA]);
		}
	}	
	if (argc >= rightA+1 ) {
		if (patching) {
			fileP = (char *)malloc(strlen(argv[rightA])+1);
			if (!fileP) xfdiff_abort(E_MALLOC);		
			strcpy(fileP,argv[rightA]);
		} else {
			fileR = (char *)malloc(strlen(argv[rightA])+1);
			if (!fileR) xfdiff_abort(E_MALLOC);		
			strcpy(fileR,argv[rightA]);
		}
	}		
	

#ifdef XFDIFF_DUMP_CORE
	gtk_init (&argc, &argv);
#else
	xfce_init (&argc, &argv);
	signal(SIGHUP,finish);
	signal(SIGSEGV,finish);
	signal(SIGKILL,finish);
	signal(SIGTERM,finish);
#endif

	diff=create_diff_window();  

	
/* process command line arguments, if any */
	if (patching){
	       	if ((prompt) || ((fileD)&&(fileP))) do_patch(); 
	}
	else {
		if ((prompt) || ((fileR)&&(fileL))) do_diff();
	}
	   
	
	gtk_main ();
	return (0);
}

