/*  xfglob
 *  Copyright (C) Edscott Wilson Garcia 
 *
 *  XFglob is based on Olivier Fourdan's setup.c and diagnostic.c, and
 *  relies on other xfce modules. It also requires command line "glob" 
 *  (which should be included with XFglob), /bin/grep
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty ofp
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
/* for _( definition, it also includes config.h: */
#include "my_intl.h"
#include "constant.h"
#include "xfce-common.h"

#ifndef HAVE_SNPRINTF
#include "snprintf.h"
#endif


#ifdef DMALLOC
#  include "dmalloc.h"
#endif

#define DEFAULT_FILTER "*.c"
#define FRAME      1
#define BOX        2
#define NOTEBOOK   3
#define SCROLLED   4
#define LABEL      5
#define ENTRY      6
#define BUTTON     7
#define SPINBUTTON 8
#define TAB_LABEL  9
#define COMBO      0

#define ADD        0
#define PACK      -1
#define SCROLL     1
#define TAB        2
#define REPACK     3
#define FPACK      4

#define GLOB "glob"

/* glob options */
static const RECURSIVE     = 0x01;
static const ANY           = 0x02;
static const EXE           = 0x04;
static const SUID          = 0x08;
/* grep options */
static const CASE_SENSITIVE= 0x400;
static const REGEXP        = 0x800;
static const WORDS         = 0x1000;
static const LINES         = 0x2000;
static const INVERT        = 0x4000;
static const COUNT         = 0x8000;

static char *ftypes[8]; /* watchout: array must be same length as in initialization */
static char *ft[]={
	"reg",
	"dir",
	"sym",
	"sock",
	"blk",
	"chr",
	"fifo",
	NULL
};

static GtkWidget *text, *bottom_hbox1, *bottom_hbox2,*bottomframe;
static GtkWidget *find;                 /* first circle */

static GtkWidget *cat = NULL;
static int pfd[2]; /* the pipe */
static pid_t Gpid;  /* glob pid, to be able to cancel search */


void set_widget(int pack,int kind,char * name,GtkWidget *widget,
		GtkWidget *parent,GtkWidget *top,int border,GList * list){
	gtk_widget_set_name (widget, name);
	gtk_object_set_data (GTK_OBJECT (top),name,widget);
	switch (kind) {
		case COMBO:  /* select input box */
			gtk_combo_set_popdown_strings (GTK_COMBO (widget),list);
			break;
		case TAB_LABEL: /* labels for notebook tabs*/
			break;
		case FRAME: /* frames */
			gtk_container_border_width (GTK_CONTAINER (widget), border);
			gtk_frame_set_shadow_type (GTK_FRAME (widget), GTK_SHADOW_ETCHED_IN);
			break;
		case BUTTON: /* buttons */
			/*break;*/
		case BOX: /* boxes */
			/*break;	*/
		case NOTEBOOK: /* notebooks */
			gtk_container_border_width (GTK_CONTAINER (widget), border);
			break;
		case SCROLLED:  /* scrolled windows */
			gtk_container_border_width (GTK_CONTAINER (widget), border);
			gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (widget),
			  GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
			break;
		case LABEL: /* labels */
			gtk_label_set_justify (GTK_LABEL (widget),GTK_JUSTIFY_RIGHT);
			break;
		case ENTRY: /* entries */
			gtk_entry_set_editable (GTK_ENTRY (widget),TRUE);
			break;
		case SPINBUTTON: /* spinbuttons */
			break;
		default: break;

	}
	
	switch (pack) {
		case TAB:
			set_notebook_tab (parent, border, widget);
			break;
		case ADD: /* container add */
			gtk_container_add (GTK_CONTAINER (parent),widget);
			break;
		case SCROLL: /* parent is scrolled */
			gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (parent), widget);
			gtk_container_set_focus_vadjustment (GTK_CONTAINER (widget),
			       gtk_scrolled_window_get_vadjustment(GTK_SCROLLED_WINDOW(parent)));
			break;

		case PACK:  
			gtk_box_pack_start (GTK_BOX (parent), widget, TRUE, TRUE, 0);
			break;
		case REPACK:
			gtk_box_pack_start (GTK_BOX (parent), widget, FALSE, TRUE, 0);
			break;
		case FPACK:
			gtk_box_pack_start (GTK_BOX (parent), widget, FALSE, FALSE, 0);
			break;
	}
	gtk_widget_show (widget);
}

static void show_cat (char *message,char *name);
static void abort_glob(GtkWidget * widget, gpointer data){
	if (Gpid) {
                kill (Gpid, SIGTERM);
		show_cat("Search canceled!\n","Find results...");
		gtk_widget_hide (bottom_hbox2);
		gtk_widget_show (bottom_hbox1);
		Gpid=0;
	}
}

static void destroy( GtkWidget *widget, gpointer   data )
{
	abort_glob(widget,data);
	gtk_main_quit();
}

static void on_clear_show_diag (GtkWidget * widget, gpointer data)
{
  guint lg;
  
  lg = gtk_text_get_length (GTK_TEXT(text));
  gtk_text_backward_delete (GTK_TEXT(text), lg);
}

static void on_ok_show_diag (GtkWidget * widget, gpointer data)
{
  abort_glob(widget,data);
  on_clear_show_diag (widget,data);
  gtk_widget_hide (GTK_WIDGET (cat));
}

static void delete_event_show_diag (GtkWidget * widget,
			GdkEvent * event, 
                        gpointer data)
{
  abort_glob(widget,data);
  on_clear_show_diag (widget,data);
  gtk_widget_hide (GTK_WIDGET (cat));
}


static void show_cat (char *message,char *name){
  GtkWidget *bbox,*scrolled,*dismiss,*clear;
  
  if ((!message) || (!strlen (message))) return; 
  if (cat != NULL){
      gtk_text_insert (GTK_TEXT (text), NULL, NULL,
		      NULL, message, strlen (message));
      if (!GTK_WIDGET_VISIBLE (cat)) gtk_widget_show (cat);
      return;
  }
    
  cat = gtk_dialog_new ();
  gtk_container_border_width (GTK_CONTAINER (cat), 5);

  gtk_window_position (GTK_WINDOW (cat), GTK_WIN_POS_CENTER);
  gtk_window_set_title (GTK_WINDOW (cat), _(name));
  gtk_widget_realize (cat);
  
  scrolled = gtk_scrolled_window_new (NULL, NULL);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (cat)->vbox), scrolled,
		      TRUE, TRUE, 0);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled),
				  GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
  gtk_widget_show (scrolled);

  text = gtk_text_new (NULL, NULL);
  gtk_widget_set_usize (text, 400, 200);
  gtk_text_set_editable (GTK_TEXT (text), FALSE);
  gtk_text_set_word_wrap (GTK_TEXT (text), FALSE);
  gtk_text_set_line_wrap (GTK_TEXT (text), TRUE);
  gtk_widget_show (text);
  gtk_container_add (GTK_CONTAINER (scrolled), text);

  bbox = gtk_hbutton_box_new ();
  gtk_button_box_set_layout (GTK_BUTTON_BOX (bbox), GTK_BUTTONBOX_END);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (bbox), 5);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (cat)->action_area), 
  		      bbox, FALSE, TRUE, 0);
  gtk_widget_show (bbox);
  clear = gtk_button_new_with_label (_("Clear"));
  gtk_container_add (GTK_CONTAINER (bbox), clear);
/*  GTK_WIDGET_SET_FLAGS (clear, GTK_CAN_DEFAULT);*/
  gtk_widget_show (clear);

  dismiss = gtk_button_new_with_label (_("Dismiss"));
  gtk_container_add (GTK_CONTAINER (bbox), dismiss);
  GTK_WIDGET_SET_FLAGS (dismiss, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (dismiss);
  gtk_widget_show (dismiss);
  
  gtk_signal_connect (GTK_OBJECT (clear), "clicked",
		      GTK_SIGNAL_FUNC (on_clear_show_diag),
		      (gpointer) GTK_WIDGET (cat));
  gtk_signal_connect (GTK_OBJECT (dismiss), "clicked",
		      GTK_SIGNAL_FUNC (on_ok_show_diag),
		      (gpointer) GTK_WIDGET (cat));
  gtk_signal_connect (GTK_OBJECT (cat), "delete_event",
		      GTK_SIGNAL_FUNC (delete_event_show_diag),
                      (gpointer) GTK_WIDGET (cat));

  gtk_text_insert (GTK_TEXT (text), NULL, NULL,
                       NULL, message, strlen (message));
  gtk_widget_show (text); /*what's this?*/
  gtk_widget_show (cat);

  return;

}


typedef struct
{
	  GtkWidget *casesense;
	  GtkWidget *recursive;
	  GtkWidget *find_button;
	  GtkWidget *cancel_button;
	  GtkWidget *abort_button;
	  GtkWidget *path_entry;
	  GtkWidget *filter_entry;
	  GtkWidget *grep_entry;
	  GtkObject *sizeG_a;
	  GtkObject *sizeM_a;
	  GtkObject *days_a;
	  GtkObject *months_a;
	  GtkWidget *sizeG;
	  GtkWidget *sizeM;
	  GtkWidget *days;
	  GtkWidget *months;
	  GtkWidget *filetype;
	  GtkWidget *any;
	  GtkWidget *suid;
	  GtkWidget *exe;
	  GtkWidget *invert;
	  GtkWidget *words;
	  GtkWidget *lines;
	  GtkWidget *count;
	  GtkWidget *regexp;
} _find_options;

_find_options find_options;

static int options=0x0;


static void toggle_option(GtkWidget * widget, gpointer data){
	int *flag;
	flag=(int *)data;
	options ^= (*flag);
/*	printf("option=0x%x\n",options);*/
}

#define RADIO_WIPE 0xfff1
static void toggle_radio(GtkWidget * widget, gpointer data){
	int *flag;
	flag=(int *)data;
	options &= RADIO_WIPE; 
	options |= (*flag);
/*	printf("option=0x%x\n",options);*/
}

/* this MAX_ARG is ugly and should be fixed with malloc() and free() */
#define MAX_ARG 30

static char *strip(char *s){
	int i,j;
	while ((s[0] == ' ') || (s[0] == '\t')) s++;
	j=strlen(s)-1; for (i=j;i>=0;i--) {
		if ((s[i]==' ')||(s[i]=='\t')) s[i]=(char) 0;
		else break;
	}
	return s;
}

static void find_ok_cb (GtkWidget * widget, gpointer data)
{
	char *argument[MAX_ARG];
	char sizeG_s[64],sizeM_s[64],days_s[64],months_s[64];
	gchar *path,*filter,*token,*s;
	int   i,j,sizeG,sizeM,days,months;

/* get the parameters set by the user... *****/
	path= gtk_entry_get_text (GTK_ENTRY (find_options.path_entry));
	path=strip(path);
	
	filter=gtk_entry_get_text (GTK_ENTRY (find_options.filter_entry));
	filter=strip(filter);
	
	token=gtk_entry_get_text (GTK_ENTRY (find_options.grep_entry));
	token=strip(token);

        /* spinbuttons: */
	sizeG=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (find_options.sizeG));
	sizeM=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (find_options.sizeM));
	days=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (find_options.days));
	months=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (find_options.months));
	
        /* select list */
	s=gtk_entry_get_text (GTK_ENTRY (GTK_COMBO (find_options.filetype)->entry));
	for (j=-1,i=0;ftypes[i]!=NULL;i++) if (strcmp(s,ftypes[i])==0) {j=i;break;}

	i=0; argument[i++]=GLOB;;
	
	argument[i++]="-P";
	
	if (options&RECURSIVE) argument[i++]="-r";
	if ((options&EXE)||(options&SUID)){
		argument[i++]="-p";
		if (options&EXE) argument[i++]="exe";
		if (options&SUID) argument[i++]="suid";
	}
	if (!(options&CASE_SENSITIVE)) argument[i++]="-i";
	if (options&COUNT)argument[i++]="-c";
	if (options&INVERT)argument[i++]="-L";
	
	if (options&WORDS) argument[i++]="-w";
	else {if (options&LINES) argument[i++]="-x";}
	if (j>0) {
		argument[i++]="-t";
		argument[i++]=ft[j];
	}

        if (days > 0) {
		argument[i++]="-d";
		sprintf(days_s,"%d",days);
		argument[i++]=days_s;
		if (months >0){
			show_cat("Using \"days\" criteria in lieu of \"months\" criteria\n",
					"Find results...");
			days=0;
		}
	}
	if (months > 0) {
		argument[i++]="-m";
		sprintf(months_s,"%d",months);
		argument[i++]=months_s;
	}
	if (sizeG > 0) {
	 	argument[i++]="-s";
		sprintf(sizeG_s,"+%d",sizeG);
		argument[i++]=sizeG_s;
		if (sizeM <= sizeG){
			show_cat("Using \"greater\" criteria in lieu of \"less\" criteria\n",
					"Find results...");
			sizeM=0;
		}
	}
	if (sizeM > 0) {
		argument[i++]="-s";
		sprintf(sizeM_s,"-%d",sizeM);
		argument[i++]=sizeM_s;
	}
	
	argument[i++]="-f";
	if (strlen(filter)>0) argument[i++]=filter; else argument[i++]="*";
	
	if (strlen(token)>0) {
		if (options&REGEXP) argument[i++]="-E";
		else argument[i++]="-e";
		argument[i++]=token;
	}
	
 	/* last argument must be the path */
	argument[i++]=path; argument[i]=(char *)0;
	/*for (j=0;j<i;j++) printf ("%s ",argument[j]);printf ("\n");*/

	show_cat("Result of ","Find results...");
	for (j=0;j<i;j++){
		show_cat(argument[j],"Find results...");
		show_cat(" ","Find results...");
	}
       	show_cat(":\n-----------------------\n","Find results...");
	
	/* spawn child process as the parent process to zap zombies (is that a hack?) */
	Gpid=0;
	if (fork()) {
		dup2(pfd[1],1); /* assign child stdout to pipe */
		close(pfd[0]);  /* not used by child */
		execvp(GLOB,argument); 
		perror("exec"); _exit(127);/* child never get here */
	}

	
}


GtkWidget * create_find (char *path)
{
  GtkAccelGroup *accel_group;
  GtkWidget *mainframe;            /* second circle */
  GtkWidget *hbox;                 /* third circle */
  GtkWidget *note_vbox;            /* fourth circle */
  GtkWidget *find_notebook;        /* fifth circle */
  GtkWidget *scrolled_window;      /* sixth circle */
  GtkWidget *page_vbox;            /* seventh circle */
  GtkWidget *upframe;              /* eigth circle  */
  GtkWidget *vbox;                 /* ninth circle */
  GtkWidget *hbox1,*hbox2,*label;  /* tenth circle */
  GSList    *radio=NULL;
  GList     *list_ftypes = NULL;  
  int i;
  

  if (path==NULL) path="~/";
  /* translation of filetypes */
  ftypes[0]=_("Regular"),
  ftypes[1]=_("Directory"),
  ftypes[2]=_("Symlink"),
  ftypes[3]=_("Socket"),
  ftypes[4]=_("Block device"),
  ftypes[5]=_("Character device"),
  ftypes[6]=_("FIFO"),
  ftypes[7]=	NULL;
  /* Initialization of filetypes */
  i=0; while (ftypes[i]) list_ftypes = g_list_append(list_ftypes,ftypes[i++]);

/* first circle : main window  */
  find = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (find, "XFglob");
  gtk_object_set_data (GTK_OBJECT (find),"XFglob",find);
  gtk_window_set_title (GTK_WINDOW (find), _("XFglob"));
  gtk_window_position (GTK_WINDOW (find), GTK_WIN_POS_MOUSE);
  gtk_widget_set_usize (find, -2, 480);
  gtk_window_set_policy (GTK_WINDOW (find), FALSE, TRUE, FALSE);
  gtk_widget_realize (find);
  accel_group = gtk_accel_group_new ();
  gtk_window_add_accel_group (GTK_WINDOW (find), accel_group);
/* second circle: frame */
  mainframe = gtk_frame_new (NULL);
  set_widget(ADD,FRAME,"mainframe",mainframe,find,find,0,NULL);
  gtk_frame_set_shadow_type (GTK_FRAME (mainframe), GTK_SHADOW_NONE);
/* fourth circle: vbox */
  note_vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"note_vbox",note_vbox,mainframe,find,5,NULL);
/* fifth circle: notebook*/
  find_notebook = gtk_notebook_new ();
  set_widget(ADD,NOTEBOOK,"find_notebook",find_notebook,note_vbox,find,0,NULL);

/* first notebook page *******************/
/* sixth circle : scrolled window */
  scrolled_window = gtk_scrolled_window_new (NULL, NULL);
  set_widget(ADD,SCROLLED,"scrolled_window1",scrolled_window,find_notebook,find,5,NULL);
/* seventh circle : vbox */
  page_vbox = gtk_vbox_new (FALSE, 0);
  set_widget(SCROLL,BOX,"page_vbox",page_vbox,scrolled_window,find,5,NULL);
/* eigth circle : frame  */
  upframe = gtk_frame_new (_("Find"));
  set_widget(PACK,FRAME,"find_upframe",upframe,page_vbox,find,5,NULL);
/* ninth circle : vbox  */
  vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"find_vbox",vbox,upframe,find,5,NULL);
/* tenth circle : hboxes */  
/* path box */
  hbox1 = gtk_hbox_new (FALSE, 0);
  set_widget(ADD,BOX,"path_hbox",hbox1,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Path : "));
  set_widget(PACK,LABEL,"path_label",label,hbox1,find,5,NULL);
  
  find_options.path_entry = gtk_entry_new ();
  set_widget(PACK,ENTRY,"find_options.path_entry",find_options.path_entry,hbox1,find,5,NULL);
  gtk_entry_set_text (GTK_ENTRY (find_options.path_entry),path);
/* Filter box : */
  hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(ADD,BOX,"filter_hbox",hbox2,vbox,find,5,NULL);
  
  label = gtk_label_new (_("File filter : "));
  set_widget(PACK,LABEL,"filter_label",label,hbox2,find,5,NULL);
  
  find_options.filter_entry = gtk_entry_new ();
  set_widget(PACK,ENTRY,"find_options.filter_entry",find_options.filter_entry,hbox2,find,5,NULL);
  gtk_entry_set_text (GTK_ENTRY (find_options.filter_entry),DEFAULT_FILTER);
  
  hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"recursive_hbox2",hbox2,vbox,find,5,NULL);
  find_options.recursive=gtk_check_button_new_with_label (_("Search subdirectories too"));
  set_widget(PACK,BUTTON,"find_options.recursive",
		  find_options.recursive,hbox2,find,2,NULL);
/****/  
/* eigth circle : frame */
  upframe = gtk_frame_new (_("Grep"));
  set_widget(PACK,FRAME,"grep_frame",upframe,page_vbox,find,5,NULL);
/* ninth circle : vbox  */
  vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"grep_vbox",vbox,upframe,find,5,NULL);
/* tenth circle : hboxes */ 
/* grep_hbox1 */
  hbox1 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"grep_hbox1",hbox1,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Containing : "));
  set_widget(PACK,LABEL,"grep_label",label,hbox1,find,5,NULL);
  
  find_options.grep_entry = gtk_entry_new ();
  set_widget(PACK,ENTRY,"find_options.grep_entry",find_options.grep_entry,hbox1,find,5,NULL);
/* grep_hbox2 */
  hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"grep_hbox2",hbox2,vbox,find,5,NULL);
  find_options.casesense=gtk_check_button_new_with_label (_("Case sensitive search"));
  set_widget(PACK,BUTTON,"find_options.casesense",
		  find_options.casesense,hbox2,find,2,NULL);

  find_options.regexp=gtk_check_button_new_with_label (_("Use regexp"));
  set_widget(PACK,BUTTON,"find_options.regexp",find_options.regexp,hbox2,find,2,NULL);
  
 
/* second notebook page *********************/  
/* sixth circle : scrolled window */
  scrolled_window = gtk_scrolled_window_new (NULL, NULL);
  set_widget(ADD,SCROLLED,"scrolled_window2",scrolled_window,find_notebook,find,5,NULL);
/* seventh circle : vbox */
  page_vbox = gtk_vbox_new (FALSE, 0);
  set_widget(SCROLL,BOX,"page_vbox2",page_vbox,scrolled_window,find,5,NULL);	
/* eigth circle : frame  */  
  upframe = gtk_frame_new (_("Size considerations"));
  set_widget(PACK,FRAME,"upframe1",upframe,page_vbox,find,5,NULL);
/* ninth circle : vbox  */
  vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"vbox1",vbox,upframe,find,5,NULL);
/* tenth circle : hboxes */  
/* sizeG box */
  
  hbox1 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"hbox1",hbox1,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Size greater than (KB): "));
  set_widget(PACK,LABEL,"SizeM_label",label,hbox1,find,5,NULL);
  
  find_options.sizeG_a = gtk_adjustment_new (0, 0,  1024*1024*1024, 64, 1, 1024);
  find_options.sizeG = gtk_spin_button_new (GTK_ADJUSTMENT
			 (find_options.sizeG_a), 1, 0);
  gtk_widget_set_usize (find_options.sizeG, 100,-2); /* before show, of course */
  set_widget(PACK,SPINBUTTON,"find_options.sizeG",find_options.sizeG,hbox1,find,5,NULL);
/* sizeM box */  
  hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"hbox2",hbox2,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Size less than (KB): "));
  set_widget(PACK,LABEL,"SizeM_label",label,hbox2,find,5,NULL);
  
  find_options.sizeM_a = gtk_adjustment_new (0, 0, 1024*1024*1024, 64, 1, 1024);
  find_options.sizeM = gtk_spin_button_new (GTK_ADJUSTMENT
			 (find_options.sizeM_a), 1, 0);
  gtk_widget_set_usize (find_options.sizeM, 100,-2); /* before show, of course */
  set_widget(PACK,SPINBUTTON,"find_options.sizeM",find_options.sizeM,hbox2,find,5,NULL);
/* eigth circle : frame  */  
  upframe = gtk_frame_new (_("Time considerations"));
  set_widget(PACK,FRAME,"upframe2",upframe,page_vbox,find,5,NULL);
/* ninth circle : vbox  */
  vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"vbox2",vbox,upframe,find,5,NULL);
/* tenth circle : hboxes */
/* days box */
  hbox1 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"hbox3",hbox1,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Created or modified in the previous : "));
  set_widget(PACK,LABEL,"days_label",label,hbox1,find,5,NULL);
  
  find_options.days_a = gtk_adjustment_new (0, 0, 366, 1, 1, 7);
  find_options.days = gtk_spin_button_new (GTK_ADJUSTMENT
			 (find_options.days_a), 1, 0);
  set_widget(PACK,SPINBUTTON,"find_options.days",find_options.days,hbox1,find,5,NULL);
  
  label = gtk_label_new (_("days"));
  set_widget(PACK,LABEL,"days_label2",label,hbox1,find,5,NULL);
/* months box */
  hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"hbox4",hbox2,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Created or modified in the previous : "));
  set_widget(PACK,LABEL,"months_label",label,hbox2,find,5,NULL);
  
  find_options.months_a = gtk_adjustment_new (0, 0, 366, 1, 1, 7);
  find_options.months = gtk_spin_button_new (GTK_ADJUSTMENT
			 (find_options.months_a), 1, 0);
  set_widget(PACK,SPINBUTTON,"find_options.months",find_options.months,hbox2,find,5,NULL);
  
  label = gtk_label_new (_("months"));
  set_widget(PACK,LABEL,"months_label2",label,hbox2,find,5,NULL);
  
/* eigth circle : frame  */  
  upframe = gtk_frame_new (_("File considerations"));
  set_widget(PACK,FRAME,"upframe3",upframe,page_vbox,find,5,NULL);
/* ninth circle : vbox  */
  vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"vbox3",vbox,upframe,find,5,NULL);
/* tenth circle : hboxes */
/* file-type box */
  hbox1 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"hbox5",hbox1,vbox,find,5,NULL);
  
  label = gtk_label_new (_("File type :"));
  set_widget(PACK,LABEL,"Ftype_label",label,hbox1,find,5,NULL);
 
  find_options.filetype = gtk_combo_new ();
  set_widget(PACK,COMBO,"Ftypes",find_options.filetype,hbox1,find,5,list_ftypes);
  g_list_free (list_ftypes);

/* Permissions box */
  hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"hbox6",hbox2,vbox,find,5,NULL);
  
  label = gtk_label_new (_("Permissions :"));
  set_widget(PACK,LABEL,"Perm_label",label,hbox2,find,5,NULL);
 
  find_options.any = gtk_radio_button_new_with_label (radio, _("Any"));
  radio = gtk_radio_button_group (GTK_RADIO_BUTTON (find_options.any));
  set_widget(PACK,BUTTON,"Any",find_options.any,hbox2,find,5,NULL);

  find_options.suid = gtk_radio_button_new_with_label (radio, _("suid"));
  radio = gtk_radio_button_group (GTK_RADIO_BUTTON (find_options.suid));
  set_widget(PACK,BUTTON,"suid",find_options.suid,hbox2,find,5,NULL);

  find_options.exe = gtk_radio_button_new_with_label (radio, _("Executable"));
  radio = gtk_radio_button_group (GTK_RADIO_BUTTON (find_options.exe));
  set_widget(PACK,BUTTON,"exe",find_options.exe,hbox2,find,5,NULL);

/* third notebook page *********************/  
/* sixth circle : scrolled window */
  scrolled_window = gtk_scrolled_window_new (NULL, NULL);
  set_widget(ADD,SCROLLED,"scrolled_window2",scrolled_window,find_notebook,find,5,NULL);
/* seventh circle : vbox */
  page_vbox = gtk_vbox_new (FALSE, 0);
  set_widget(SCROLL,BOX,"page_vbox2",page_vbox,scrolled_window,find,5,NULL);	
/* eigth circle : frame  */  
  upframe = gtk_frame_new (_("Grep considerations"));
  set_widget(PACK,FRAME,"upframe1",upframe,page_vbox,find,5,NULL);
/* ninth circle : vbox  */
  vbox = gtk_vbox_new (FALSE, 0);
  set_widget(ADD,BOX,"vbox1",vbox,upframe,find,5,NULL);
/* tenth circle : hboxes */
 hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"grep_opt1",hbox2,vbox,find,5,NULL);
  find_options.invert=gtk_check_button_new_with_label (_("Output files where no match is found"));
  set_widget(PACK,BUTTON,"find_options.invert",
		  find_options.invert,hbox2,find,2,NULL);

 hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"grep_opt2",hbox2,vbox,find,5,NULL);
  find_options.count=gtk_check_button_new_with_label (_("Output count of matching lines"));
  set_widget(PACK,BUTTON,"find_options.count",
		  find_options.count,hbox2,find,2,NULL);  

 hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"grep_opt3",hbox2,vbox,find,5,NULL);
  find_options.words=gtk_check_button_new_with_label (_("Match whole words only"));
  set_widget(PACK,BUTTON,"find_options.words",
		  find_options.words,hbox2,find,2,NULL);  

 hbox2 = gtk_hbox_new (FALSE, 0);
  set_widget(PACK,BOX,"grep_opt4",hbox2,vbox,find,5,NULL);
  find_options.lines=gtk_check_button_new_with_label (_("Match whole lines only"));
  set_widget(PACK,BUTTON,"find_options.lines",
		  find_options.lines,hbox2,find,2,NULL);  

  

  
/*********************************/
  
  
/* show the notebook pages: */
  
/* fifth circle : notebook tabs stuff */
  label = gtk_label_new (_("Find"));
  set_widget(TAB,TAB_LABEL,"find_tab_label",label,find_notebook,find,0,NULL);

  label = gtk_label_new (_("Glob options"));
  set_widget(TAB,TAB_LABEL,"glob_label",label,find_notebook,find,1,NULL);

  label = gtk_label_new (_("Grep options"));
  set_widget(TAB,TAB_LABEL,"grep_label",label,find_notebook,find,2,NULL);

/* bottom frame stuff *******/

/* fifth circle:  bottom frame */
  bottomframe = gtk_frame_new (NULL);
  set_widget(REPACK,FRAME,"mainframe",bottomframe,note_vbox,find,5,NULL);
/* sixth circle : hbox and contents */
  hbox = gtk_hbutton_box_new ();
  set_widget(ADD,BOX,"bottomframe1",hbox,bottomframe,find,0,NULL);

/* visible part */  
  bottom_hbox1 = gtk_hbutton_box_new ();
  set_widget(PACK,BOX,"bottomframe1",bottom_hbox1,hbox,find,0,NULL);

  find_options.find_button = gtk_button_new_with_label (_("Find"));
  set_widget(PACK,BUTTON,"find_button",find_options.find_button,bottom_hbox1,find,5,NULL);
  GTK_WIDGET_SET_FLAGS (find_options.find_button, GTK_CAN_DEFAULT);
  gtk_widget_grab_default (find_options.find_button);
  
  find_options.cancel_button = gtk_button_new_with_label (_("Quit"));
  set_widget(PACK,BUTTON,"cancel_button",find_options.cancel_button,bottom_hbox1,find,5,NULL);
  GTK_WIDGET_SET_FLAGS (find_options.cancel_button, GTK_CAN_DEFAULT);

/* invisible part: */  
  bottom_hbox2 = gtk_hbutton_box_new ();
  set_widget(PACK,BOX,"bottomframe2",bottom_hbox2,hbox,find,0,NULL);
 
  label = gtk_label_new (_("working..."));
  set_widget(PACK,LABEL,"abort_tab_label",label,bottom_hbox2,find,0,NULL);  
  
  find_options.abort_button = gtk_button_new_with_label (_("Cancel Search"));
  set_widget(PACK,BUTTON,"abort_button",find_options.abort_button,bottom_hbox2,find,5,NULL);
  GTK_WIDGET_SET_FLAGS (find_options.abort_button, GTK_CAN_DEFAULT);

  gtk_widget_hide(bottom_hbox2);

  

/* and finally, the signals */
  
  gtk_signal_connect (GTK_OBJECT (find), "destroy",
				GTK_SIGNAL_FUNC (destroy), (gpointer) NULL);
  gtk_signal_connect (GTK_OBJECT (find_options.cancel_button), "clicked",
				GTK_SIGNAL_FUNC (destroy), (gpointer) NULL);
  gtk_signal_connect (GTK_OBJECT (find_options.find_button), "clicked",
				GTK_SIGNAL_FUNC (find_ok_cb), (gpointer) NULL);
  gtk_signal_connect (GTK_OBJECT (find_options.abort_button), "clicked",
				GTK_SIGNAL_FUNC (abort_glob), (gpointer) NULL);
  
/* toggle options: */
  gtk_signal_connect (GTK_OBJECT (find_options.casesense), "clicked",
			GTK_SIGNAL_FUNC (toggle_option),(gpointer) &CASE_SENSITIVE);
  gtk_signal_connect (GTK_OBJECT (find_options.regexp), "clicked",
			GTK_SIGNAL_FUNC (toggle_option),(gpointer) &REGEXP);
  gtk_signal_connect (GTK_OBJECT (find_options.recursive), "clicked",
				GTK_SIGNAL_FUNC (toggle_option),(gpointer) &RECURSIVE);
  gtk_signal_connect (GTK_OBJECT (find_options.words), "clicked",
				GTK_SIGNAL_FUNC (toggle_option),(gpointer) &WORDS);
  gtk_signal_connect (GTK_OBJECT (find_options.lines), "clicked",
				GTK_SIGNAL_FUNC (toggle_option),(gpointer) &LINES);
  gtk_signal_connect (GTK_OBJECT (find_options.invert), "clicked",
				GTK_SIGNAL_FUNC (toggle_option),(gpointer) &INVERT);
  gtk_signal_connect (GTK_OBJECT (find_options.count), "clicked",
				GTK_SIGNAL_FUNC (toggle_option),(gpointer) &COUNT);
  gtk_signal_connect (GTK_OBJECT (find_options.suid), "clicked",
				GTK_SIGNAL_FUNC (toggle_radio),(gpointer) &SUID);
  gtk_signal_connect (GTK_OBJECT (find_options.any), "clicked",
				GTK_SIGNAL_FUNC (toggle_radio),(gpointer) &ANY);
  gtk_signal_connect (GTK_OBJECT (find_options.exe), "clicked",
				GTK_SIGNAL_FUNC (toggle_radio),(gpointer) &EXE);

  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(find_options.recursive),TRUE);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(find_options.exe),TRUE);/* this forces the next line to be executed (hack)*/
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(find_options.any),TRUE);


  return find;
}

gboolean
process_find_messages (gpointer client_data, gint source,
		       GdkInputCondition condition)
{
 char *buffer,line[256];
 static gboolean nothing_found; 
/*printf("input found\n");fflush(NULL);*/
	buffer=line;
	while (1){ 
		if (!read(pfd[0],buffer,1)) return TRUE;
		if (buffer[0]=='\n') {
			buffer[1]=(char) 0;
			if (strncmp(line,"GLOB DONE=",strlen("GLOB DONE="))==0) {
				/* eliminate cancel-search button */
				gtk_widget_hide (bottom_hbox2);
				gtk_widget_show (bottom_hbox1);
				gtk_widget_realize (find);
				Gpid=0;
				if (nothing_found) show_cat("Nothing found...\n","Find results..."); 
				/*printf("%s",line);fflush(NULL);*/
				return TRUE;
			}
			if ((strncmp(line,"PID=",4)==0)) {
				Gpid=atoi(line+4);
				/*printf("Glob PID=%d\n",Gpid);fflush(NULL);*/
				/* show cancel-search button */
				gtk_widget_hide (bottom_hbox1);
				gtk_widget_show (bottom_hbox2);
				gtk_widget_realize (find);
				nothing_found=TRUE;
				return (TRUE);
			}
			show_cat(line,"Find results...");
			nothing_found=FALSE;
			buffer=line;
			continue;
		}
		buffer++;
	}
  return (1);
}


int main (int argc, char **argv)
{
        xfce_init (&argc, &argv);
	if (argc>1) find=create_find(argv[1]); else find=create_find(NULL);
	gtk_widget_show (find);
		/* open the pipes... */
	if (pipe(pfd) < 0) { perror("pipe"); return 1; }
  /* call process_message everytime the child's pipe is flushed */
	gdk_input_add (pfd[0], GDK_INPUT_READ,
		  (GdkInputFunction) process_find_messages,
		  (gpointer) ((long) pfd[0]));
	gtk_main ();
	close (pfd[0]); close (pfd[1]); /* close the pipes */
	return (0);
}

