
/* globber.h */
/* 
   Copyright 2000 Edscott Wilson Garcia

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA.  */

/*****************************************************************/

/* globber in its own .o file and link it in later:*/

int globber(char *input,int (*operate)(char *),char *filter);

#ifdef GLOBBER_C
#define EXTERN
#else
#define EXTERN extern
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <glob.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <time.h>

#ifndef GLOB_TILDE
#define GLOB_TILDE 0x0
#endif
#ifndef GLOB_ONLYDIR
#define GLOB_ONLYDIR 0x0
#endif

EXTERN int options; /* initialize at main() to 0x0; */
EXTERN long size;   /* initialize at main() to 0x0  */
EXTERN int type;     /* initialize at main() to S_IFREG */
EXTERN long month_t;   /* initialize at main() to 0x0  */
EXTERN long unsigned day_t;    /* initialize at main() to 0x0  */

#define RECURSIVE    0x01
#define VERBOSE      0x02
#define FILTERED     0x04
#define PID          0x08

#define IGNORE_CASE  0x10
#define REG_EXP      0x20
#define INVERT       0x40
#define COUNT        0x80
#define WORDS_ONLY   0x100
#define LINES_ONLY   0x200
#define ZERO_BYTE    0x400

#define MONTH_T 2628000
#define DAY_T 86400


