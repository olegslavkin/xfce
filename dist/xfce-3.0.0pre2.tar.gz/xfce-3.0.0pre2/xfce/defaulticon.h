/* XPM */
static char *defaulticon[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    38    28        6            1",
/*
   colors 
 */
  ". c #595959",
  "# c #ffffff",
  "a c #dfdfdf",
  "b c #797979",
  "c c #b6b6b6",
  "d c #5151fb",
/*
   pixels 
 */
  ".....................................#",
  ".###################################.#",
  ".#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.#",
  ".#accccccccccccccccccccccccccccccccb.#",
  ".#bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.#",
  ".....................................#",
  ".###################################.#",
  ".#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.#",
  ".#abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbab.#",
  ".#abccccccccccccccccccccccccccccccab.#",
  ".#abcccccccccddddcccccccddccccccccab.#",
  ".#abccccccccccddddcccccddcccccccccab.#",
  ".#abcccccccccccddddcccddccccccccccab.#",
  ".#abcccccccccccddddccddcccccccccccab.#",
  ".#abccccccccccccddddddccccccccccccab.#",
  ".#abcccccccccccccddddcccccccccccccab.#",
  ".#abccccccccccccccddddccccccccccccab.#",
  ".#abcccccccccccccdddddccccccccccccab.#",
  ".#abccccccccccccddcddddcccccccccccab.#",
  ".#abcccccccccccddcccddddccccccccccab.#",
  ".#abccccccccccddcccccddddcccccccccab.#",
  ".#abcccccccccddccccccddddcccccccccab.#",
  ".#abccccccccddccccccccddddccccccccab.#",
  ".#abccccccccccccccccccccccccccccccab.#",
  ".#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.#",
  ".#bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.#",
  ".....................................#",
  "######################################"};
