/* XPM */
static char *schedule[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48       8            1",
/*
   colors 
 */
  ". m mask c none",
  "# c #595959",
  "a c #ffffff",
  "b c #a2a2a2",
  "c c #797979",
  "d c #dfdfdf",
  "e c #595959",
  "f c #0000ff",
/*
   pixels 
 */
  "................................................",
  "................................................",
  "................................................",
  "................................................",
  "..........############################a.........",
  ".........#abcbcbcbcbcbcbcbcbcbcbcbcbcbca........",
  "........#abc#c#c#c#c#c#c#c#c#c#c#c#c#c##a.......",
  "........#acbcbcbcbcbcbcbcbcbcbcbcbcbcbc#a.......",
  "........#acbcbcbcbcbcbcbcbcbcbcbcbcbcbc#a.......",
  "........#acdccbcbcbcbcbcbcbcbcbcbcbcbcd#a.......",
  "........#acdcdddddddddddddddddddddddddd#a.......",
  "........#acdcdeedbdeedbdeedbdeedbdeedbd#a.......",
  "........#acdcdeedbdeedbdeedbdeedbdeedbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddfbdddfbdddfbdddfbdddfbd#a.......",
  "........#acdcdeedbddddbddddbddddbddddbd#a.......",
  "........#acdcddddbddddbddddbddddbddddbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddfbdddfbdddfbdddfbdddfbd#a.......",
  "........#acdcdeedbddddbddddbddddbddddbd#a.......",
  "........#acdcddddbddddbddddbddddbddddbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddfbdddfbdddfbdddfbdddfbd#a.......",
  "........#acdcdeedbddddbddddbddddbddddbd#a.......",
  "........#acdcddddbddddbddddbddddbddddbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddfbdddfbdddfbdddfbdddfbd#a.......",
  "........#acdcdeedbddddbddddbddddbddddbd#a.......",
  "........#acdcddddbddddbddddbddddbddddbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddfbdddfbdddfbdddfbdddfbd#a.......",
  "........#acdcdeedbddddbddddbddddbddddbd#a.......",
  "........#acdcddddbddddbddddbddddbddddbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddfbdddfbdddfbdddfbdddfbd#a.......",
  "........#acdcdeedbddddbddddbddddbddddbd#a.......",
  "........#acdcddddbddddbddddbddddbddddbd#a.......",
  "........#acdcdbbbbbbbbbbbbbbbbbbbbbbbbd#a.......",
  "........#acdcdddddddddddddddddddddddddd#a.......",
  ".........#adcdddddddddddddddddddddddddd#a.......",
  "..........#a############################a.......",
  "...........#aaaaaaaaaaaaaaaaaaaaaaaaaaaaa.......",
  "................................................",
  "................................................",
  "................................................",
  "................................................",
  "................................................",
  "................................................"};
